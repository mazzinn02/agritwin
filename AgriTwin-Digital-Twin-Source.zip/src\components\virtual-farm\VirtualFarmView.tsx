import React, { useState, useEffect, useMemo } from 'react';
import { ref, onValue, set } from '../../lib/firebase';
import { db } from '../../lib/firebase';
import { 
  Sprout, 
  Droplet, 
  Thermometer, 
  Activity, 
  MapPin, 
  Radio, 
  Download, 
  LineChart, 
  Settings2, 
  X, 
  Sparkles, 
  Zap, 
  CheckCircle2, 
  AlertCircle,
  Wind,
  Gauge,
  Clock
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ResponsiveContainer, AreaChart, Area, Tooltip } from 'recharts';
import PlantCanopySvg from '../common/PlantCanopySvg';
import { computeGrowthStatus } from '../../lib/gdd-calculator';
import { DailyActionBanner } from '../common/DailyActionBanner';
import { useUserMode } from '../../context/UserModeContext';

export interface PlotBedData {
  id: string;
  nodeId: string;
  name: string;
  crop: string;
  variety: string;
  cropType: string;
  healthScore: number;
  healthStatus: 'Excellent' | 'Good' | 'Needs Attention';
  soilMoisture: number;
  optimalMoistureMin: number;
  optimalMoistureMax: number;
  airTemp: number;
  vpd: number;
  soilPh: number;
  nitrogen: number;
  dripIrrigationActive: boolean;
  hvacActive: boolean;
  statusText: string;
}

const DEFAULT_PLOTS: PlotBedData[] = [
  {
    id: 'plot_1',
    nodeId: 'NODE-TOM-01',
    name: 'Plot 1: North-West Greenhouse',
    crop: 'Tomato',
    variety: 'Sarpan F1-STH-520',
    cropType: 'tomato',
    healthScore: 95,
    healthStatus: 'Excellent',
    statusText: 'Optimal Growth & Moisture',
    soilMoisture: 48,
    optimalMoistureMin: 45,
    optimalMoistureMax: 60,
    airTemp: 24.2,
    vpd: 1.05,
    soilPh: 6.5,
    nitrogen: 45,
    dripIrrigationActive: true,
    hvacActive: true
  },
  {
    id: 'plot_2',
    nodeId: 'NODE-LET-02',
    name: 'Plot 2: North-East Greenhouse',
    crop: 'Lettuce',
    variety: 'Butterhead Green',
    cropType: 'lettuce',
    healthScore: 78,
    healthStatus: 'Needs Attention',
    statusText: 'Water Needed (Below 55%)',
    soilMoisture: 52,
    optimalMoistureMin: 55,
    optimalMoistureMax: 70,
    airTemp: 22.5,
    vpd: 0.88,
    soilPh: 6.2,
    nitrogen: 50,
    dripIrrigationActive: false,
    hvacActive: true
  },
  {
    id: 'plot_3',
    nodeId: 'NODE-PEP-03',
    name: 'Plot 3: South-East Canopy',
    crop: 'Pepper',
    variety: 'Bell Pepper Red',
    cropType: 'pepper',
    healthScore: 90,
    healthStatus: 'Good',
    statusText: 'Shade Fan Recommended',
    soilMoisture: 42,
    optimalMoistureMin: 40,
    optimalMoistureMax: 55,
    airTemp: 26.1,
    vpd: 1.25,
    soilPh: 6.8,
    nitrogen: 40,
    dripIrrigationActive: false,
    hvacActive: false
  },
  {
    id: 'plot_4',
    nodeId: 'NODE-STR-04',
    name: 'Plot 4: South-West Field',
    crop: 'Strawberry',
    variety: 'Chandler Sweet',
    cropType: 'strawberry',
    healthScore: 92,
    healthStatus: 'Good',
    statusText: 'Sugar Ripening On Track',
    soilMoisture: 50,
    optimalMoistureMin: 45,
    optimalMoistureMax: 60,
    airTemp: 23.4,
    vpd: 1.12,
    soilPh: 6.4,
    nitrogen: 42,
    dripIrrigationActive: false,
    hvacActive: true
  }
];

const generate24hSparklineData = (baseMoisture: number, baseTemp: number) => {
  const points = [];
  for (let i = 0; i <= 24; i += 3) {
    const hourLabel = `${i}:00`;
    const varianceMoist = Math.sin(i / 3) * 3 + (Math.random() * 2 - 1);
    const varianceTemp = Math.cos(i / 4) * 2 + (Math.random() * 1.5 - 0.75);
    points.push({
      time: hourLabel,
      moisture: +(baseMoisture + varianceMoist).toFixed(1),
      temp: +(baseTemp + varianceTemp).toFixed(1)
    });
  }
  return points;
};

export const VirtualFarmView: React.FC = () => {
  const navigate = useNavigate();
  const { isFarmer } = useUserMode();
  const [plots, setPlots] = useState<PlotBedData[]>(DEFAULT_PLOTS);
  const [selectedPlot, setSelectedPlot] = useState<PlotBedData | null>(null);
  const [allIrrigating, setAllIrrigating] = useState(false);
  const [bulkActionFeedback, setBulkActionFeedback] = useState<string | null>(null);
  const [plotTimers, setPlotTimers] = useState<Record<string, number>>({});

  useEffect(() => {
    const plotsRef = ref(db, 'plots');
    const unsubPlots = onValue(plotsRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        setPlots(prev => prev.map(p => {
          const live = val[p.id];
          if (!live) return p;
          return {
            ...p,
            healthScore: live.healthScore || p.healthScore,
            healthStatus: live.healthStatus || p.healthStatus,
            soilMoisture: live.moisture || p.soilMoisture,
            airTemp: live.temp || p.airTemp
          };
        }));
      }
    });

    const devicesRef = ref(db, 'devices');
    const unsubDevices = onValue(devicesRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        setPlots(prev => prev.map(p => {
          const pDev = val[p.id];
          if (!pDev) return p;
          return {
            ...p,
            dripIrrigationActive: pDev.irrigation?.enabled ?? p.dripIrrigationActive,
            hvacActive: pDev.hvac?.enabled ?? p.hvacActive
          };
        }));
      }
    });

    return () => {
      unsubPlots();
      unsubDevices();
    };
  }, []);

  // Timer loop
  useEffect(() => {
    const interval = setInterval(() => {
      setPlotTimers(prev => {
        const next = { ...prev };
        let changed = false;
        Object.entries(next).forEach(([k, val]) => {
          const s = Number(val);
          if (s > 1) {
            next[k] = s - 1;
            changed = true;
          } else {
            delete next[k];
            changed = true;
          }
        });
        return changed ? next : prev;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const averageFarmHealth = useMemo(() => {
    if (plots.length === 0) return 90;
    const sum = plots.reduce((acc, p) => acc + p.healthScore, 0);
    return Math.round(sum / plots.length);
  }, [plots]);

  const handleIrrigateAll = async () => {
    setAllIrrigating(true);
    setBulkActionFeedback('Actuating drip irrigation valves across all 4 plots...');
    
    for (const p of plots) {
      await set(ref(db, `devices/${p.id}/irrigation`), {
        enabled: true,
        mode: 'auto'
      });
    }

    setPlots(prev => prev.map(p => ({ ...p, dripIrrigationActive: true })));

    setTimeout(() => {
      setAllIrrigating(false);
      setBulkActionFeedback('All 4 plot drip lines actively running.');
      setTimeout(() => setBulkActionFeedback(null), 3000);
    }, 1200);
  };

  const handleSinglePlotWater = async (e: React.MouseEvent, plotId: string) => {
    e.stopPropagation();
    setPlotTimers(prev => ({ ...prev, [plotId]: 15 * 60 }));
    await set(ref(db, `devices/${plotId}/irrigation`), {
      enabled: true,
      mode: 'manual',
      autoOffAt: Date.now() + 15 * 60 * 1000
    });
  };

  const handleSinglePlotFan = async (e: React.MouseEvent, plotId: string) => {
    e.stopPropagation();
    const plot = plots.find(p => p.id === plotId);
    const curr = plot?.hvacActive ?? false;
    await set(ref(db, `devices/${plotId}/hvac`), {
      enabled: !curr,
      mode: 'manual'
    });
  };

  const handleExportTelemetry = () => {
    const headers = ['Plot ID', 'Node ID', 'Crop', 'Variety', 'Health Score', 'Soil Moisture (%)', 'Air Temp (°C)', 'VPD (kPa)', 'Soil pH', 'Drip State'];
    const rows = plots.map(p => [
      p.id,
      p.nodeId,
      p.crop,
      p.variety,
      `${p.healthScore}%`,
      `${p.soilMoisture}%`,
      `${p.airTemp}°C`,
      `${p.vpd} kPa`,
      p.soilPh,
      p.dripIrrigationActive ? 'ON' : 'OFF'
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'agritwin_spatial_farm_telemetry.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const selectedGrowth = computeGrowthStatus(selectedPlot?.id || 'plot_1');

  return (
    <div className="space-y-6 text-slate-800 font-sans">
      
      {/* ================= 1. NON-BLOCKING FLOATING TOP FARM BAR ================= */}
      <div className="bg-white/95 backdrop-blur-md rounded-3xl p-5 border border-slate-200/80 shadow-sm flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        
        {/* Left: Farm Geolocation & Gateway Status */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-700 border border-emerald-200 shadow-xs">
              <Sprout className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-xl font-black text-slate-900 tracking-tight">Campus Greenhouse Alpha</h2>
                <span className="text-[10px] font-mono font-extrabold uppercase px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                  4 Active Beds
                </span>
              </div>
              <div className="flex items-center space-x-2 text-xs text-slate-500 font-medium mt-0.5">
                <MapPin className="w-3.5 h-3.5 text-sky-600" />
                <span>IIIT Dharwad Campus &bull; 15.4589° N, 75.0078° E</span>
              </div>
            </div>
          </div>

          <div className="h-8 w-px bg-slate-200 hidden sm:block" />

          {/* Live Edge Gateway Sync Badge */}
          <div className="flex items-center space-x-2 bg-slate-50 px-3.5 py-1.5 rounded-2xl border border-slate-200">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <div className="text-[11px] font-bold text-slate-700">
              Gateway #1 &bull; <span className="text-emerald-700">Live Stream (2s ago)</span>
            </div>
          </div>
        </div>

        {/* Right: Overall Farm Health Dial & Bulk Quick Actions */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center space-x-2.5 bg-emerald-50/80 px-4 py-2 rounded-2xl border border-emerald-200/80">
            <Gauge className="w-4 h-4 text-emerald-600" />
            <div>
              <div className="text-[9px] text-emerald-800 uppercase font-extrabold">Farm Health</div>
              <div className="text-sm font-black text-emerald-800">{averageFarmHealth}% Optimal</div>
            </div>
          </div>

          <button
            onClick={handleIrrigateAll}
            disabled={allIrrigating}
            className="flex items-center space-x-1.5 px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition-all cursor-pointer active:scale-95 disabled:opacity-50"
          >
            <Droplet className={`w-3.5 h-3.5 ${allIrrigating ? 'animate-bounce' : ''}`} />
            <span>{allIrrigating ? 'Irrigating...' : 'Irrigate All Plots'}</span>
          </button>

          <button
            onClick={handleExportTelemetry}
            className="flex items-center space-x-1.5 px-3.5 py-2.5 bg-white hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold border border-slate-200 shadow-xs transition-all cursor-pointer active:scale-95"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Bulk Action Notification Bar */}
      {bulkActionFeedback && (
        <div className="p-3 bg-sky-50 border border-sky-200 rounded-2xl text-xs font-bold text-sky-800 flex items-center space-x-2 animate-fadeIn">
          <Activity className="w-4 h-4 text-sky-600 animate-spin" />
          <span>{bulkActionFeedback}</span>
        </div>
      )}

      {/* Daily Action Banner */}
      <DailyActionBanner />

      {/* ================= 2. SPATIAL 2x2 PLOT BED LAYOUT GRID ================= */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {plots.map((plot) => {
          const sparklineData = generate24hSparklineData(plot.soilMoisture, plot.airTemp);
          const growthStatus = computeGrowthStatus(plot.id);
          const isOptimal = plot.healthScore >= 85;
          const isWarning = plot.healthScore >= 65 && plot.healthScore < 85;
          const activeSecs = plotTimers[plot.id] || 0;
          const isWatering = activeSecs > 0 || plot.dripIrrigationActive;

          const healthBadgeBg = isOptimal 
            ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
            : isWarning 
            ? 'bg-amber-50 text-amber-800 border-amber-200' 
            : 'bg-rose-50 text-rose-800 border-rose-200';

          return (
            <div
              key={plot.id}
              onClick={() => setSelectedPlot(plot)}
              className="bg-slate-100/90 rounded-3xl p-4 border border-slate-200/90 shadow-sm hover:shadow-md hover:border-sky-300 transition-all duration-300 group cursor-pointer flex flex-col justify-between relative overflow-hidden"
            >
              {/* Subtle Pattern */}
              <div 
                className="absolute inset-0 opacity-20 pointer-events-none"
                style={{
                  backgroundImage: `radial-gradient(#94a3b8 1px, transparent 1px)`,
                  backgroundSize: '24px 24px',
                }}
              />

              {/* Top Crop Canopy Banner */}
              <div className="relative bg-white/95 rounded-2xl p-4 border border-slate-200/80 shadow-xs flex items-center justify-between mb-4 z-10">
                <div className="flex items-center space-x-3.5">
                  <div className="w-16 h-16 bg-slate-50 rounded-2xl border border-slate-200/70 flex items-center justify-center shrink-0 overflow-hidden">
                    <PlantCanopySvg
                      stage={growthStatus.currentStage.key}
                      cropType={plot.crop}
                      size={60}
                    />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="text-base font-black text-slate-900 group-hover:text-sky-700 transition-colors">
                        {plot.crop}
                      </h3>
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 border border-slate-200">
                        {plot.nodeId}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 font-medium">{plot.variety} &bull; {plot.id.toUpperCase()}</p>
                    <div className="text-[11px] font-bold text-sky-700 mt-0.5">
                      {plot.statusText}
                    </div>
                  </div>
                </div>

                <div className={`px-3 py-1.5 rounded-xl text-xs font-black border shadow-2xs flex items-center space-x-1.5 ${healthBadgeBg}`}>
                  {isOptimal ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <AlertCircle className="w-3.5 h-3.5 text-amber-600" />}
                  <span>{plot.healthScore}% Health</span>
                </div>
              </div>

              {/* High-Density Telemetry Card */}
              <div className="bg-white/95 rounded-2xl p-4 border border-slate-200/80 shadow-xs space-y-4 z-10">
                
                {/* 4-Up Live Metrics Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  
                  {/* Moisture */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 text-center">
                    <div className="flex items-center justify-center space-x-1 text-[10px] text-slate-500 font-bold uppercase mb-0.5">
                      <Droplet className="w-3 h-3 text-sky-600" />
                      <span>Moisture</span>
                    </div>
                    <div className="font-black text-slate-900 text-base">{plot.soilMoisture}%</div>
                    <div className="text-[9px] text-emerald-700 font-bold">
                      {isFarmer ? 'Optimal Soil' : `${plot.optimalMoistureMin}-${plot.optimalMoistureMax}%`}
                    </div>
                  </div>

                  {/* Temp */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 text-center">
                    <div className="flex items-center justify-center space-x-1 text-[10px] text-slate-500 font-bold uppercase mb-0.5">
                      <Thermometer className="w-3 h-3 text-rose-500" />
                      <span>Temp</span>
                    </div>
                    <div className="font-black text-slate-900 text-base">{plot.airTemp}°C</div>
                    <div className="text-[9px] text-slate-400 font-medium">Comfortable</div>
                  </div>

                  {/* DAP / Growth */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 text-center">
                    <div className="flex items-center justify-center space-x-1 text-[10px] text-slate-500 font-bold uppercase mb-0.5">
                      <Sprout className="w-3 h-3 text-emerald-600" />
                      <span>Growth</span>
                    </div>
                    <div className="font-black text-slate-900 text-base">Day {growthStatus.dap}</div>
                    <div className="text-[9px] text-emerald-700 font-bold">On Schedule</div>
                  </div>

                  {/* Device State */}
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 text-center">
                    <div className="flex items-center justify-center space-x-1 text-[10px] text-slate-500 font-bold uppercase mb-0.5">
                      <Droplet className="w-3 h-3 text-sky-600" />
                      <span>Drip Valve</span>
                    </div>
                    <div className="font-black text-sky-700 text-base">{isWatering ? 'ON' : 'OFF'}</div>
                    <div className="text-[9px] text-slate-400 font-medium">Auto-Ready</div>
                  </div>
                </div>

                {/* Micro-Sparkline Chart (in Agronomist mode or farmer quick view) */}
                {!isFarmer && (
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 space-y-1">
                    <div className="flex justify-between items-center text-[10px] text-slate-500 font-bold">
                      <span>24h Moisture & Temp Stability Sparkline</span>
                      <span className="text-sky-700 font-mono">Real-Time Ingestion</span>
                    </div>
                    <div className="h-14 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={sparklineData}>
                          <defs>
                            <linearGradient id={`moistGrad_${plot.id}`} x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4} />
                              <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                            </linearGradient>
                          </defs>
                          <Tooltip
                            contentStyle={{ backgroundColor: '#ffffff', borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '10px', padding: '4px 8px' }}
                            formatter={(v: any, n: string) => [n === 'moisture' ? `${v}%` : `${v}°C`, n === 'moisture' ? 'Moisture' : 'Temp']}
                          />
                          <Area type="monotone" dataKey="moisture" stroke="#0284c7" strokeWidth={2} fillOpacity={1} fill={`url(#moistGrad_${plot.id})`} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                )}

                {/* Farmer 1-Tap Execution Buttons Row */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-100">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={(e) => handleSinglePlotWater(e, plot.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center space-x-1.5 transition-all shadow-xs cursor-pointer active:scale-95 ${
                        isWatering
                          ? 'bg-sky-600 text-white animate-pulse'
                          : 'bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200'
                      }`}
                    >
                      <Droplet className="w-3.5 h-3.5 fill-current" />
                      <span>{isWatering ? (activeSecs > 0 ? `Watering... (${Math.floor(activeSecs/60)}m)` : 'Watering Active') : 'Water 15 Mins'}</span>
                    </button>

                    <button
                      onClick={(e) => handleSinglePlotFan(e, plot.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all shadow-xs cursor-pointer active:scale-95 ${
                        plot.hvacActive
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                      }`}
                    >
                      <Wind className="w-3.5 h-3.5" />
                      <span>{plot.hvacActive ? 'Fan ON' : 'Turn Fan ON'}</span>
                    </button>
                  </div>

                  <span className="text-[11px] text-sky-700 font-bold hover:underline">
                    Inspect &rarr;
                  </span>
                </div>

                {/* Phenological Stage Progress Bar */}
                <div className="space-y-1 pt-1">
                  <div className="flex justify-between items-center text-[10px] text-slate-600 font-bold">
                    <span>{growthStatus.currentStage.label} &bull; Day {growthStatus.dap} of {growthStatus.totalDurationDays}</span>
                    <span className="text-sky-700 font-mono font-bold">{growthStatus.stageCompletionPct}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 via-sky-500 to-amber-500 rounded-full transition-all duration-500"
                      style={{ width: `${growthStatus.stageCompletionPct}%` }}
                    />
                  </div>
                </div>

              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Plot Detail Modal */}
      {selectedPlot && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto relative shadow-2xl space-y-6 text-slate-800">
            
            <div className="flex justify-between items-start border-b border-slate-200 pb-4">
              <div className="flex items-center space-x-3">
                <div className="w-14 h-14 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-center">
                  <PlantCanopySvg
                    stage={selectedGrowth.currentStage.key}
                    cropType={selectedPlot.crop}
                    size={52}
                  />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-xl font-black text-slate-900">{selectedPlot.crop}</h3>
                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                      {selectedPlot.nodeId}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    {selectedPlot.variety} &bull; <strong className="text-sky-700 font-bold">{selectedPlot.name}</strong>
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedPlot(null)}
                className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-slate-700 uppercase">Growth Stage: {selectedGrowth.currentStage.label}</span>
                <span className="text-xs font-black text-sky-700">{selectedGrowth.accumulatedGdd} GDD</span>
              </div>
              <p className="text-xs text-slate-600 font-medium">
                {selectedGrowth.currentStage.description}
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-500 block font-medium">Soil Moisture</span>
                <span className="font-black text-slate-900 text-base">{selectedPlot.soilMoisture}%</span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-500 block font-medium">Air Temp</span>
                <span className="font-black text-slate-900 text-base">{selectedPlot.airTemp}°C</span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-500 block font-medium">Health Status</span>
                <span className="font-black text-emerald-700 text-base">{selectedPlot.healthScore}% Optimal</span>
              </div>
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                <span className="text-slate-500 block font-medium">Drip State</span>
                <span className="font-black text-sky-700 text-base">{selectedPlot.dripIrrigationActive ? 'Active' : 'Standby'}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                onClick={() => navigate('/analytics')}
                className="flex items-center justify-center space-x-2 py-3 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition-all cursor-pointer active:scale-95"
              >
                <LineChart className="w-4 h-4" />
                <span>Open Plot Analytics</span>
              </button>

              <button
                onClick={() => navigate('/control')}
                className="flex items-center justify-center space-x-2 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-extrabold shadow-sm transition-all cursor-pointer active:scale-95"
              >
                <Settings2 className="w-4 h-4" />
                <span>Control Plot Devices</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VirtualFarmView;
