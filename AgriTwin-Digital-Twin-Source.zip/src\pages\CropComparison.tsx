import React, { useState, useEffect } from 'react';
import { ref, get } from '../lib/firebase';
import { db } from '../lib/firebase';
import { fetchComparisonData, saveComparisonSession } from '../lib/comparison-helper';
import { LineChart as RechartsLineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Save, Layers, CheckSquare, Square } from 'lucide-react';

const PLOTS = [
  { id: 'plot_1', name: 'Plot 1: Tomato (Sarpan STH-520)', color: '#10B981' },
  { id: 'plot_2', name: 'Plot 2: Lettuce (Butterhead)', color: '#0284C7' },
  { id: 'plot_3', name: 'Plot 3: Pepper (Bell Red)', color: '#D97706' },
  { id: 'plot_4', name: 'Plot 4: Strawberry (Chandler)', color: '#E11D48' }
];

export const CropComparison = () => {
  const [selectedPlots, setSelectedPlots] = useState<string[]>(['plot_1', 'plot_2', 'plot_3']);
  const [parameter, setParameter] = useState('airTemp');
  const [comparisonData, setComparisonData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [sessionName, setSessionName] = useState('');
  const [savedSessions, setSavedSessions] = useState<any[]>([]);

  useEffect(() => {
    const fetchSessions = async () => {
      const snapshot = await get(ref(db, 'comparison_sessions'));
      if (snapshot.exists()) {
        const sessions = Object.entries(snapshot.val()).map(([id, data]: any) => ({ id, ...data }));
        setSavedSessions(sessions);
      }
    };
    fetchSessions();
    handleCompare(['plot_1', 'plot_2', 'plot_3'], 'airTemp');
  }, []);

  const togglePlot = (plotId: string) => {
    if (selectedPlots.includes(plotId)) {
      if (selectedPlots.length <= 1) return;
      const updated = selectedPlots.filter(id => id !== plotId);
      setSelectedPlots(updated);
      handleCompare(updated, parameter);
    } else {
      const updated = [...selectedPlots, plotId];
      setSelectedPlots(updated);
      handleCompare(updated, parameter);
    }
  };

  const handleCompare = async (targetPlots = selectedPlots, targetParam = parameter) => {
    setLoading(true);
    const finalData = await fetchComparisonData(targetPlots, targetParam);
    setComparisonData(finalData);
    setLoading(false);
  };

  const handleSaveSession = async () => {
    if (!sessionName || !selectedPlots.length) return;
    await saveComparisonSession(sessionName, selectedPlots, parameter);
    setSessionName('');
    const snapshot = await get(ref(db, 'comparison_sessions'));
    if (snapshot.exists()) {
      const sessions = Object.entries(snapshot.val()).map(([id, data]: any) => ({ id, ...data }));
      setSavedSessions(sessions);
    }
    alert('Comparison session saved successfully!');
  };

  const loadSession = (session: any) => {
    const targetPlots = session.plots || [session.plot1, session.plot2].filter(Boolean);
    setSelectedPlots(targetPlots);
    setParameter(session.parameter || 'airTemp');
    handleCompare(targetPlots, session.parameter || 'airTemp');
  };

  return (
    <div className="space-y-6 text-slate-800">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 flex items-center">
            <Layers className="mr-3 text-sky-600 w-8 h-8" />
            Cross-Crop Multi-Plot Comparison
          </h2>
          <p className="text-slate-500 text-sm mt-1 font-medium">Compare up to 4 plots side-by-side across any biophysical or soil parameter</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Controls Sidebar */}
        <div className="bg-white/95 backdrop-blur-sm p-6 rounded-3xl shadow-sm border border-slate-200/80 space-y-6">
          {/* Multi-Select Plot Picker */}
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">Select Target Plots</label>
            <div className="space-y-2">
              {PLOTS.map(p => (
                <div
                  key={p.id}
                  onClick={() => togglePlot(p.id)}
                  className={`p-3 rounded-2xl border text-xs font-bold flex items-center justify-between cursor-pointer transition-colors ${
                    selectedPlots.includes(p.id)
                      ? 'bg-sky-50 text-sky-800 border-sky-200 shadow-xs'
                      : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span>{p.name}</span>
                  {selectedPlots.includes(p.id) ? (
                    <CheckSquare className="w-4 h-4 text-sky-600" />
                  ) : (
                    <Square className="w-4 h-4 text-slate-300" />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Parameter Picker */}
          <div>
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">Telemetry Parameter</label>
            <select
              value={parameter}
              onChange={(e) => {
                setParameter(e.target.value);
                handleCompare(selectedPlots, e.target.value);
              }}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500"
            >
              <option value="airTemp">Air Temperature (°C)</option>
              <option value="soilMoisture">Soil Moisture (%)</option>
              <option value="humidity">Humidity (%)</option>
              <option value="light">Light Level (lx)</option>
              <option value="nitrogen">Nitrogen (mg/kg)</option>
              <option value="soilPh">Soil pH</option>
            </select>
          </div>

          {/* Save Session Form */}
          <div className="pt-4 border-t border-slate-200 space-y-2">
            <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider">Save Analytics Session</label>
            <div className="flex space-x-2">
              <input
                type="text"
                placeholder="Session Name..."
                value={sessionName}
                onChange={e => setSessionName(e.target.value)}
                className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-900 outline-none"
              />
              <button
                onClick={handleSaveSession}
                className="p-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl shadow-xs cursor-pointer active:scale-95"
              >
                <Save className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Saved Sessions List */}
          {savedSessions.length > 0 && (
            <div className="pt-2 space-y-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Saved Sessions</span>
              <div className="space-y-1.5 max-h-40 overflow-y-auto">
                {savedSessions.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => loadSession(s)}
                    className="w-full text-left p-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-semibold border border-slate-200/80 truncate cursor-pointer"
                  >
                    {s.name || `Session ${i+1}`} ({s.parameter})
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Main Comparison Chart Area */}
        <div className="lg:col-span-3 bg-white/95 backdrop-blur-sm p-6 rounded-3xl shadow-sm border border-slate-200/80 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-200 pb-3">
            <h3 className="text-base font-extrabold text-slate-900">Multi-Plot Overlay Telemetry Curve</h3>
            <span className="text-xs text-slate-500 font-medium">Auto-refreshes with live sensor stream</span>
          </div>

          <div className="h-[480px]">
            {loading && comparisonData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-slate-400 font-medium text-xs">Loading comparison streams...</div>
            ) : comparisonData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <RechartsLineChart data={comparisonData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />
                  <XAxis dataKey="time" stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: '#FFFFFF', borderRadius: '16px', border: '1px solid #E2E8F0', color: '#0F172A', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                  <Legend />
                  {selectedPlots.map(pid => {
                    const plotInfo = PLOTS.find(p => p.id === pid);
                    return (
                      <Line
                        key={pid}
                        type="monotone"
                        dataKey={pid}
                        name={plotInfo?.name || pid}
                        stroke={plotInfo?.color || '#0284c7'}
                        strokeWidth={3}
                        dot={{ r: 0 }}
                        activeDot={{ r: 6 }}
                      />
                    );
                  })}
                </RechartsLineChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400 font-medium text-xs">No data available for selected plots.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CropComparison;
