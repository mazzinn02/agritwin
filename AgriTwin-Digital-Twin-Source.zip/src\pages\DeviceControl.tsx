import React, { useState, useEffect } from 'react';
import { ref, onValue, set } from '../lib/firebase';
import { db } from '../lib/firebase';
import { Settings2, Droplet, Wind, Sun } from 'lucide-react';

const PLOTS = [
  { id: 'plot_1', name: 'Plot 1: Tomato (Sarpan F1-STH-520)' },
  { id: 'plot_2', name: 'Plot 2: Lettuce (Butterhead Green)' },
  { id: 'plot_3', name: 'Plot 3: Pepper (Bell Pepper Red)' },
  { id: 'plot_4', name: 'Plot 4: Strawberry (Chandler Sweet)' }
];

export const DeviceControl = () => {
  const [selectedPlot, setSelectedPlot] = useState('plot_1');
  const [controls, setControls] = useState<any>(null);

  useEffect(() => {
    const deviceRef = ref(db, `devices/${selectedPlot}`);
    const unsubscribe = onValue(deviceRef, (snapshot) => {
      setControls(snapshot.val());
    });
    return () => unsubscribe();
  }, [selectedPlot]);

  const toggleDevice = async (device: string, currentEnabled: boolean, mode: string) => {
    await set(ref(db, `devices/${selectedPlot}/${device}`), {
      enabled: !currentEnabled,
      mode: (mode || 'auto').toLowerCase()
    });
  };

  const toggleMode = async (device: string, enabled: boolean, currentMode: string) => {
    const isAuto = (currentMode || '').toLowerCase() === 'auto';
    await set(ref(db, `devices/${selectedPlot}/${device}`), {
      enabled: enabled,
      mode: isAuto ? 'manual' : 'auto'
    });
  };

  if (!controls) return <div className="p-8 text-slate-500 font-medium">Loading device actuators...</div>;

  const devices = [
    { key: 'irrigation', label: 'Smart Irrigation Valve', icon: Droplet, activeColor: 'bg-sky-600', state: controls.irrigation || { enabled: false, mode: 'auto' } },
    { key: 'hvac', label: 'HVAC & Ventilation Fan', icon: Wind, activeColor: 'bg-emerald-600', state: controls.hvac || controls.ventilation || { enabled: false, mode: 'auto' } },
    { key: 'growLight', label: 'PAR LED Grow Lights', icon: Sun, activeColor: 'bg-amber-500', state: controls.growLight || { enabled: false, mode: 'manual' } },
  ];

  return (
    <div className="space-y-6 text-slate-800">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 flex items-center">
            <Settings2 className="mr-3 text-sky-600 w-8 h-8" />
            Device Actuation & Control Panel
          </h2>
          <p className="text-slate-500 text-sm mt-1 font-medium">Real-time remote control of irrigation solenoids, HVAC, and grow lighting</p>
        </div>

        <div className="bg-white px-4 py-2 rounded-2xl border border-slate-200 shadow-xs flex items-center space-x-3">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Plot:</span>
          <select 
            value={selectedPlot} 
            onChange={(e) => setSelectedPlot(e.target.value)}
            className="bg-slate-50 text-slate-900 text-xs font-bold rounded-xl px-3 py-1.5 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
          >
            {PLOTS.map(p => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {devices.map(device => {
          const Icon = device.icon;
          const { enabled, mode } = device.state;
          const isAuto = (mode || '').toLowerCase() === 'auto';
          const displayMode = isAuto ? 'Auto' : 'Manual';
          return (
            <div key={device.key} className="bg-white/95 backdrop-blur-sm rounded-3xl p-8 shadow-sm border border-slate-200/80 relative overflow-hidden group flex flex-col hover:border-slate-300 transition-all">
              
              <div className="flex justify-between items-start mb-8 z-10">
                <div className={`p-4 rounded-2xl ${enabled ? `${device.activeColor} text-white shadow-xs` : 'bg-slate-100 text-slate-500'} transition-colors`}>
                  <Icon className="w-8 h-8" />
                </div>
                <div className="flex flex-col items-end space-y-3">
                  <button 
                    onClick={() => toggleDevice(device.key, enabled, mode)}
                    className={`w-14 h-8 rounded-full p-1 transition-colors relative shadow-inner cursor-pointer ${enabled ? 'bg-sky-600' : 'bg-slate-200'}`}
                    title={`Toggle ${device.label}`}
                  >
                    <div className={`w-6 h-6 bg-white rounded-full shadow-xs transition-transform ${enabled ? 'translate-x-6' : 'translate-x-0'}`} />
                  </button>
                  <button 
                    onClick={() => toggleMode(device.key, enabled, mode)}
                    className={`text-xs px-2.5 py-1 rounded-lg border font-bold uppercase tracking-wider cursor-pointer transition-all active:scale-95 ${
                      isAuto ? 'bg-sky-50 text-sky-700 border-sky-200' : 'bg-slate-100 text-slate-600 border-slate-300'
                    }`}
                  >
                    {displayMode} Mode
                  </button>
                </div>
              </div>

              <div className="z-10 mt-auto">
                <h3 className="text-lg font-black text-slate-900 mb-1">{device.label}</h3>
                <p className={`text-xs font-bold uppercase tracking-wider ${enabled ? 'text-emerald-700' : 'text-slate-400'}`}>
                  {enabled ? `Active & Running (${displayMode})` : 'Standby Mode'}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default DeviceControl;
