// Mock Firebase Realtime Database Implementation for Prototype
// This replaces the actual firebase/database module to run locally without Java/Emulator dependencies.

type Callback = (snapshot: any) => void;

class MockDatabase {
  data: any = {};
  listeners: Record<string, Callback[]> = {};

  getPath(path: string) {
    return path.split('/').filter(Boolean);
  }

  resolvePath(obj: any, pathParts: string[]) {
    let current = obj;
    for (const part of pathParts) {
      if (current === undefined || current === null) return undefined;
      current = current[part];
    }
    return current;
  }

  setPath(obj: any, pathParts: string[], value: any) {
    let current = obj;
    for (let i = 0; i < pathParts.length - 1; i++) {
      const part = pathParts[i];
      if (!current[part]) current[part] = {};
      current = current[part];
    }
    const last = pathParts[pathParts.length - 1];
    if (last) {
      current[last] = value;
    }
  }

  deletePath(obj: any, pathParts: string[]) {
    if (pathParts.length === 0) return;
    let current = obj;
    for (let i = 0; i < pathParts.length - 1; i++) {
      const part = pathParts[i];
      if (!current[part]) return;
      current = current[part];
    }
    const last = pathParts[pathParts.length - 1];
    if (last && current) {
      delete current[last];
    }
  }

  notify(path: string) {
    // Notify exact listeners
    if (this.listeners[path]) {
      const val = this.resolvePath(this.data, this.getPath(path));
      const snapshot = {
        exists: () => val !== undefined && val !== null,
        val: () => val
      };
      this.listeners[path].forEach(cb => cb(snapshot));
    }
    
    // Notify parent listeners
    const parts = this.getPath(path);
    while (parts.length > 0) {
      parts.pop();
      const parentPath = parts.join('/');
      if (this.listeners[parentPath]) {
        const val = this.resolvePath(this.data, parts);
        const snapshot = {
          exists: () => val !== undefined && val !== null,
          val: () => val
        };
        this.listeners[parentPath].forEach(cb => cb(snapshot));
      }
    }
  }
}

const mockDb = new MockDatabase();

export const db = mockDb;

export const ref = (database: any, path: string) => {
  return { path };
};

export const onValue = (dbRef: any, callback: Callback) => {
  const path = dbRef.path;
  if (!mockDb.listeners[path]) {
    mockDb.listeners[path] = [];
  }
  mockDb.listeners[path].push(callback);
  
  // Initial call
  const val = mockDb.resolvePath(mockDb.data, mockDb.getPath(path));
  callback({
    exists: () => val !== undefined && val !== null,
    val: () => val
  });

  return () => {
    // unsubscribe
    mockDb.listeners[path] = mockDb.listeners[path].filter(cb => cb !== callback);
  };
};

// Update get to handle mock queries
const originalGet = async (dbRef: any) => {
  const path = dbRef.path;
  const val = mockDb.resolvePath(mockDb.data, mockDb.getPath(path));
  return {
    exists: () => val !== undefined && val !== null,
    val: () => val
  };
};

export const get = async (queryRef: any) => {
  if (!queryRef._isQuery) return originalGet(queryRef);
  
  const path = queryRef.path;
  const val = mockDb.resolvePath(mockDb.data, mockDb.getPath(path));
  
  if (!val) {
    return { exists: () => false, val: () => null };
  }

  let results = Object.entries(val);
  
  const orderConstraint = queryRef.queryConstraints.find((c: any) => c.type === 'orderByChild');
  const startConstraint = queryRef.queryConstraints.find((c: any) => c.type === 'startAt');
  const endConstraint = queryRef.queryConstraints.find((c: any) => c.type === 'endAt');

  if (orderConstraint) {
    const key = orderConstraint.path;
    
    if (startConstraint) {
      results = results.filter(([_, item]: any) => item[key] >= startConstraint.value);
    }
    if (endConstraint) {
      results = results.filter(([_, item]: any) => item[key] <= endConstraint.value);
    }
    
    results.sort(([_, a]: any, [__, b]: any) => a[key] - b[key]);
  }

  const filteredVal = Object.fromEntries(results);

  return {
    exists: () => results.length > 0,
    val: () => filteredVal
  };
};

export const set = async (dbRef: any, value: any) => {
  const path = dbRef.path;
  mockDb.setPath(mockDb.data, mockDb.getPath(path), value);
  mockDb.notify(path);
};

export const push = async (dbRef: any, value: any) => {
  const path = dbRef.path;
  const pushId = Math.random().toString(36).substring(2, 15);
  const fullPath = `${path}/${pushId}`;
  mockDb.setPath(mockDb.data, mockDb.getPath(fullPath), value);
  mockDb.notify(path); // notify parent
  return { key: pushId };
};

export const remove = async (dbRef: any) => {
  const path = dbRef.path;
  mockDb.deletePath(mockDb.data, mockDb.getPath(path));
  mockDb.notify(path);
};

export const query = (dbRef: any, ...queryConstraints: any[]) => {
  return { path: dbRef.path, _isQuery: true, queryConstraints };
};

export const orderByChild = (path: string) => {
  return { type: 'orderByChild', path };
};

export const startAt = (value: any) => {
  return { type: 'startAt', value };
};

export const endAt = (value: any) => {
  return { type: 'endAt', value };
};

export const signInWithGoogle = async () => {
  return { user: { displayName: 'Demo Student', email: 'student@college.edu' } };
};

export const getAccessToken = async () => {
  return 'demo_token';
};
