import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AppLayout } from './components/Layout/AppLayout';
import { UserModeProvider } from './context/UserModeContext';

import Dashboard from './pages/Dashboard';
import CropComparison from './pages/CropComparison';
import CropVision from './pages/CropVision';
import FieldLog from './pages/FieldLog';
import Analytics from './pages/Analytics';
import AIAdvisor from './pages/AIAdvisor';
import WhatIfSimulator from './pages/WhatIfSimulator';
import VirtualFarm from './pages/VirtualFarm';
import MapView from './pages/MapView';
import CameraFeed from './pages/CameraFeed';
import MySensors from './pages/MySensors';
import DeviceControl from './pages/DeviceControl';
import Crops from './pages/farm-management/Crops';

function App() {
  return (
    <UserModeProvider>
      <Router>
        <Routes>
          <Route path="/" element={<AppLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="vision" element={<CropVision />} />
            <Route path="history" element={<FieldLog />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="advisor" element={<AIAdvisor />} />
            <Route path="what-if" element={<WhatIfSimulator />} />
            <Route path="virtual-farm" element={<VirtualFarm />} />
            <Route path="map" element={<MapView />} />
            <Route path="camera" element={<CameraFeed />} />
            <Route path="sensors" element={<MySensors />} />
            <Route path="control" element={<DeviceControl />} />
            <Route path="compare" element={<CropComparison />} />
            {/* Farm Management Routes */}
            <Route path="farm-management/crops" element={<Crops />} />
          </Route>
        </Routes>
      </Router>
    </UserModeProvider>
  );
}

export default App;
