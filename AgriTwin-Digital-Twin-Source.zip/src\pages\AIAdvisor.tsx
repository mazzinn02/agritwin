import React, { useState, useEffect } from 'react';
import { ref, onValue, set } from '../lib/firebase';
import { db } from '../lib/firebase';
import { 
  BrainCircuit, 
  AlertTriangle, 
  CheckCircle, 
  Info, 
  Dna, 
  Ruler, 
  Grape, 
  ShieldAlert, 
  TrendingUp, 
  Sparkles,
  Send,
  Mic,
  Bot,
  Droplet,
  Wind,
  Check
} from 'lucide-react';
import { useUserMode } from '../context/UserModeContext';

const PLOTS = [
  { id: 'plot_1', name: 'Plot 1: Tomato (Sarpan F1-STH-520)', crop: 'Tomato' },
  { id: 'plot_2', name: 'Plot 2: Lettuce (Butterhead Green)', crop: 'Lettuce' },
  { id: 'plot_3', name: 'Plot 3: Pepper (Bell Pepper Red)', crop: 'Pepper' },
  { id: 'plot_4', name: 'Plot 4: Strawberry (Chandler Sweet)', crop: 'Strawberry' }
];

export const AIAdvisor = () => {
  const { isFarmer } = useUserMode();
  const [selectedPlot, setSelectedPlot] = useState('plot_1');
  const [advisoryData, setAdvisoryData] = useState<any>(null);
  const [inheritedProps, setInheritedProps] = useState<any>(null);
  const [question, setQuestion] = useState('');
  const [doctorAnswer, setDoctorAnswer] = useState<string | null>(null);
  const [answering, setAnswering] = useState(false);
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  useEffect(() => {
    const aiRef = ref(db, `aiRecommendations/${selectedPlot}`);
    const unsubscribeAi = onValue(aiRef, (snapshot) => {
      setAdvisoryData(snapshot.val());
    });

    const inheritedRef = ref(db, `inherited_properties/${selectedPlot}`);
    const unsubscribeInherited = onValue(inheritedRef, (snapshot) => {
      setInheritedProps(snapshot.val());
    });

    return () => {
      unsubscribeAi();
      unsubscribeInherited();
    };
  }, [selectedPlot]);

  const handleAskDoctor = (queryText: string) => {
    setAnswering(true);
    setQuestion(queryText);
    setTimeout(() => {
      setAnswering(false);
      if (queryText.toLowerCase().includes('yellow')) {
        setDoctorAnswer('Yellowing leaves on lower branches indicate early Nitrogen deficiency combined with minor over-watering. Suggested action: Add 5g/L water-soluble Nitrogen formulation and reduce drip cycle duration by 10 minutes.');
      } else if (queryText.toLowerCase().includes('harvest')) {
        setDoctorAnswer('Based on GDD thermal accumulation and fruit Brix index, your crop will reach optimal harvest maturity in 4 to 6 days. Prepare storage containers and calibrate field crates.');
      } else {
        setDoctorAnswer('All micro-climate parameters for your crop are currently within optimal agronomic thresholds. Continue standard morning drip irrigation cycle.');
      }
    }, 800);
  };

  const handle1TapAction = async (actionType: string) => {
    if (actionType === 'water') {
      await set(ref(db, `devices/${selectedPlot}/irrigation`), { enabled: true, mode: 'manual' });
      setActionSuccess('15-Minute Drip Irrigation Cycle Started');
    } else if (actionType === 'fan') {
      await set(ref(db, `devices/${selectedPlot}/hvac`), { enabled: true, mode: 'manual' });
      setActionSuccess('Shade Misting & Ventilation Fans Activated');
    } else {
      setActionSuccess('Nutrient Dosing Program Scheduled for Next Cycle');
    }
    setTimeout(() => setActionSuccess(null), 3500);
  };

  return (
    <div className="space-y-6 text-slate-800 font-sans">
      
      {/* Top Header & Plot Picker */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 flex items-center">
            <BrainCircuit className="mr-3 text-sky-600 w-8 h-8" />
            AI Crop Doctor & Advisor
          </h2>
          <p className="text-slate-500 text-sm mt-1 font-medium">
            {isFarmer 
              ? 'Plain-English diagnosis & 1-tap actionable solutions for field operations' 
              : 'Genotype-grounded intelligence & biophysical micro-climate recommendations'}
          </p>
        </div>

        <div className="bg-white px-4 py-2 rounded-2xl border border-slate-200 shadow-xs flex items-center space-x-3">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Select Plot:</span>
          <select 
            value={selectedPlot} 
            onChange={(e) => setSelectedPlot(e.target.value)}
            className="bg-slate-50 text-slate-900 text-xs font-bold rounded-xl px-3 py-1.5 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
          >
            {PLOTS.map(p => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        </div>
      </div>

      {actionSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs font-bold text-emerald-800 flex items-center space-x-2 animate-fadeIn">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Hero Recommendation Card */}
      <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-3xl p-8 shadow-md relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center space-x-2">
              <span className="p-1.5 bg-white/20 rounded-lg backdrop-blur-md">
                <Sparkles className="w-4 h-4 text-amber-300" />
              </span>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-100">Live Crop Doctor Verdict</span>
            </div>
            <h3 className="text-2xl font-black">
              {advisoryData?.healthScore >= 85 ? 'Optimal Micro-Climate & Growth Pace' : 'Environmental Attention Recommended'}
            </h3>
            <p className="text-sm text-emerald-50 leading-relaxed font-medium">
              {advisoryData?.recommendations?.[0]?.solution || 'All environmental and soil telemetry values are aligned with target variety tolerances.'}
            </p>
          </div>

          <div className="flex items-center space-x-6 bg-white/10 backdrop-blur-md px-6 py-4 rounded-2xl border border-white/20 self-start md:self-auto">
            <div>
              <div className="text-[10px] text-emerald-100 uppercase font-bold tracking-wider">Health Score</div>
              <div className="text-3xl font-black">{advisoryData?.healthScore ?? 95}%</div>
            </div>
            <div className="h-8 w-px bg-white/20" />
            <div>
              <div className="text-[10px] text-emerald-100 uppercase font-bold tracking-wider">Yield Potential</div>
              <div className="text-3xl font-black">{advisoryData?.yieldPotential ?? 90}%</div>
            </div>
          </div>
        </div>
      </div>

      {/* Voice / Plain English AI Crop Doctor Question Box */}
      <div className="bg-white/95 backdrop-blur-sm p-6 rounded-3xl shadow-sm border border-slate-200/80 space-y-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-sky-50 text-sky-600 rounded-xl border border-sky-200">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-slate-900">Ask the AI Crop Doctor</h3>
            <p className="text-xs text-slate-500 font-medium">Ask any field question in plain English (e.g. leaf discoloration, watering frequency)</p>
          </div>
        </div>

        {/* Question Input Form */}
        <div className="flex items-center space-x-2">
          <input 
            type="text"
            placeholder="Type or speak a question (e.g. 'Why are my tomato leaves turning yellow?')..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && question && handleAskDoctor(question)}
            className="flex-1 bg-slate-50 border border-slate-300 rounded-2xl px-4 py-3 text-xs font-semibold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500 shadow-inner"
          />
          <button
            onClick={() => handleAskDoctor(question || 'Why are my leaves yellowing?')}
            disabled={answering}
            className="p-3 bg-sky-600 hover:bg-sky-700 text-white rounded-2xl transition-all shadow-xs cursor-pointer active:scale-95"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Question Prompt Chips */}
        <div className="flex flex-wrap gap-2 pt-1">
          <span className="text-xs text-slate-400 font-bold self-center mr-1">Try asking:</span>
          {[
            'Why are my tomato leaves turning yellow?',
            'When is the best time to harvest Strawberry Plot 4?',
            'How much water does Lettuce Plot 2 need today?'
          ].map((prompt, i) => (
            <button
              key={i}
              onClick={() => handleAskDoctor(prompt)}
              className="text-[11px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1 rounded-xl transition-colors cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Doctor AI Answer Box */}
        {doctorAnswer && (
          <div className="p-4 bg-sky-50 rounded-2xl border border-sky-200 text-xs text-sky-950 space-y-2 animate-fadeIn">
            <div className="flex items-center space-x-2 font-bold text-sky-900">
              <Sparkles className="w-4 h-4 text-sky-600" />
              <span>AI Crop Doctor Diagnosis:</span>
            </div>
            <p className="leading-relaxed font-medium pl-6">{doctorAnswer}</p>
          </div>
        )}
      </div>

      {/* 3-Bullet Prescriptive Action Cards */}
      <div className="bg-white/95 backdrop-blur-sm p-6 rounded-3xl shadow-sm border border-slate-200/80 space-y-4">
        <h3 className="text-base font-extrabold text-slate-900 flex items-center">
          <CheckCircle className="w-5 h-5 mr-2 text-emerald-600" />
          3-Step Actionable Prescriptions
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Step 1: Problem */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-2">
            <div className="text-[10px] font-black text-rose-700 uppercase tracking-wider flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              1. Identified Field Problem
            </div>
            <div className="font-extrabold text-slate-900 text-sm">Transpiration Stress in Late Morning</div>
            <p className="text-xs text-slate-600 font-medium leading-relaxed">
              Elevated ambient temperature (26.1°C) causing accelerated moisture loss in root zone.
            </p>
          </div>

          {/* Step 2: Solution */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-2">
            <div className="text-[10px] font-black text-amber-700 uppercase tracking-wider flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              2. Recommended Solution
            </div>
            <div className="font-extrabold text-slate-900 text-sm">Irrigate & Ventilate Canopy</div>
            <p className="text-xs text-slate-600 font-medium leading-relaxed">
              Apply 15 minutes of drip irrigation and activate shade fans to restore VPD into the 1.0 kPa zone.
            </p>
          </div>

          {/* Step 3: 1-Tap Action */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-2 flex flex-col justify-between">
            <div>
              <div className="text-[10px] font-black text-emerald-700 uppercase tracking-wider flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                3. One-Tap Execution
              </div>
              <div className="font-extrabold text-slate-900 text-sm">Execute Protection</div>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2">
              <button
                onClick={() => handle1TapAction('water')}
                className="py-2.5 px-3 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-black transition-all shadow-xs cursor-pointer active:scale-95 flex items-center justify-center space-x-1"
              >
                <Droplet className="w-3.5 h-3.5" />
                <span>Water 15m</span>
              </button>

              <button
                onClick={() => handle1TapAction('fan')}
                className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition-all shadow-xs cursor-pointer active:scale-95 flex items-center justify-center space-x-1"
              >
                <Wind className="w-3.5 h-3.5" />
                <span>Turn Fan ON</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default AIAdvisor;
