import { ref, get, set } from './firebase';
import { db } from './firebase';

export const fetchComparisonData = async (arg1: string[] | string, arg2: string, arg3?: string) => {
  let plots: string[] = [];
  let parameter: string = '';

  if (Array.isArray(arg1)) {
    plots = arg1;
    parameter = arg2;
  } else if (arg3 !== undefined) {
    plots = [arg1, arg2];
    parameter = arg3;
  } else {
    plots = [arg1];
    parameter = arg2;
  }

  const mergedMap = new Map();

  for (const plotId of plots) {
    const snap = await get(ref(db, `historicalData/${plotId}`));
    const vals = snap.val() || {};
    Object.values(vals).forEach((val: any) => {
      const timeLabel = new Date(val.timestamp).toLocaleTimeString();
      const existing = mergedMap.get(timeLabel) || { time: timeLabel };
      mergedMap.set(timeLabel, {
        ...existing,
        [plotId]: val[parameter]
      });
    });
  }

  const finalData = Array.from(mergedMap.values()).sort((a, b) => a.time.localeCompare(b.time)).slice(-20);
  return finalData;
};

export const saveComparisonSession = async (sessionName: string, arg1: string[] | string, arg2: string, arg3?: string) => {
  if (!sessionName) return;

  let plots: string[] = [];
  let parameter: string = '';

  if (Array.isArray(arg1)) {
    plots = arg1;
    parameter = arg2;
  } else if (arg3 !== undefined) {
    plots = [arg1, arg2];
    parameter = arg3;
  } else {
    plots = [arg1];
    parameter = arg2;
  }

  const sessionRef = ref(db, `comparison_sessions/${Date.now()}`);
  await set(sessionRef, {
    name: sessionName,
    plots,
    plot1: plots[0] || 'plot_1',
    plot2: plots[1] || 'plot_2',
    parameter,
    createdAt: new Date().toISOString()
  });
};
