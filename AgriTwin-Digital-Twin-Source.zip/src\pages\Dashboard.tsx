import React, { useEffect, useState } from 'react';
import { ref, onValue, get, set } from '../lib/firebase';
import { db } from '../lib/firebase';
import { 
  Thermometer, 
  Droplets, 
  Sun, 
  Activity, 
  Zap, 
  Beaker, 
  Sprout, 
  ChevronDown,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Wind,
  Clock,
  Sparkles
} from 'lucide-react';
import { CropGrowthTracker } from '../components/dashboard/CropGrowthTracker';
import { DailyActionBanner } from '../components/common/DailyActionBanner';
import { useUserMode } from '../context/UserModeContext';

const PLOTS = [
  { id: 'plot_1', name: 'Plot 1: Tomato (Sarpan F1-STH-520)', crop: 'Tomato', variety: 'Sarpan F1-STH-520' },
  { id: 'plot_2', name: 'Plot 2: Lettuce (Butterhead Green)', crop: 'Lettuce', variety: 'Butterhead Green' },
  { id: 'plot_3', name: 'Plot 3: Pepper (Bell Pepper Red)', crop: 'Pepper', variety: 'Bell Pepper Red' },
  { id: 'plot_4', name: 'Plot 4: Strawberry (Chandler Sweet)', crop: 'Strawberry', variety: 'Chandler Sweet' }
];

export const Dashboard = () => {
  const { isFarmer } = useUserMode();
  const [selectedPlotId, setSelectedPlotId] = useState('plot_1');
  const [liveData, setLiveData] = useState<any>(null);
  const [farmMeta, setFarmMeta] = useState<any>(null);
  const [deviceControl, setDeviceControl] = useState<any>(null);
  const [aiAdvisory, setAiAdvisory] = useState<any>(null);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [showAllParams, setShowAllParams] = useState(false);
  const [wateringTimer, setWateringTimer] = useState<number>(0);

  useEffect(() => {
    const liveRef = ref(db, `live_readings/${selectedPlotId}`);
    const unsubscribeLive = onValue(liveRef, (snapshot) => {
      const val = snapshot.val();
      if (val) {
        setLiveData(val);
      } else {
        get(ref(db, `sensorReadings/${selectedPlotId}`)).then((fallbackSnap) => {
          setLiveData(fallbackSnap.val());
        });
      }
    });

    const metaRef = ref(db, 'farm_meta');
    const unsubscribeMeta = onValue(metaRef, (snapshot) => {
      setFarmMeta(snapshot.val());
    });

    const deviceRef = ref(db, `devices/${selectedPlotId}`);
    const unsubscribeDevice = onValue(deviceRef, (snapshot) => {
      setDeviceControl(snapshot.val());
    });

    const aiRef = ref(db, `aiRecommendations/${selectedPlotId}`);
    const unsubscribeAi = onValue(aiRef, (snapshot) => {
      setAiAdvisory(snapshot.val());
    });

    const alertsRef = ref(db, 'alerts');
    const unsubscribeAlerts = onValue(alertsRef, (snapshot) => {
      const vals = snapshot.val();
      if (vals) {
        setAlerts(Object.values(vals).filter((a: any) => !a.read).sort((a: any, b: any) => b.timestamp - a.timestamp));
      } else {
        setAlerts([]);
      }
    });

    return () => {
      unsubscribeLive();
      unsubscribeMeta();
      unsubscribeDevice();
      unsubscribeAi();
      unsubscribeAlerts();
    };
  }, [selectedPlotId]);

  // Countdown loop for 1-tap watering
  useEffect(() => {
    if (wateringTimer > 0) {
      const t = setTimeout(() => setWateringTimer(wateringTimer - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [wateringTimer]);

  if (!liveData) return <div className="p-8 text-slate-500 font-medium">Loading live farm telemetry...</div>;

  const env = liveData.environmental || liveData;
  const soil = liveData.soil || liveData;
  const terrain = liveData.terrain || liveData;
  const water = liveData.water_quality || liveData;

  const selectedPlotObj = PLOTS.find(p => p.id === selectedPlotId) || PLOTS[0];

  const handleQuickWater = async () => {
    setWateringTimer(15 * 60); // 15 mins
    await set(ref(db, `devices/${selectedPlotId}/irrigation`), {
      enabled: true,
      mode: 'manual',
      autoOffAt: Date.now() + 15 * 60 * 1000
    });
  };

  const handleQuickFan = async () => {
    const currentState = deviceControl?.hvac?.enabled ?? false;
    await set(ref(db, `devices/${selectedPlotId}/hvac`), {
      enabled: !currentState,
      mode: 'manual'
    });
  };

  const isDripOn = wateringTimer > 0 || (deviceControl?.irrigation?.enabled ?? false);
  const isFanOn = deviceControl?.hvac?.enabled ?? false;

  return (
    <div className="space-y-6">
      
      {/* Top Header with Live Plot Picker */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-3xl font-black text-slate-900 tracking-tight">{farmMeta?.name || 'Campus Greenhouse Alpha'}</h2>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
              {isFarmer ? '🌾 Farmer View' : '🔬 Agronomist View'}
            </span>
          </div>
          <p className="text-slate-500 text-sm mt-1 font-medium">{farmMeta?.location || 'Campus Greenhouse Alpha'} &bull; 4 Active Farm Beds</p>
        </div>

        <div className="flex items-center space-x-3">
          {/* Functional Plot Selector Dropdown */}
          <div className="bg-white px-3.5 py-2 rounded-2xl border border-slate-200/80 flex items-center space-x-2 shadow-xs">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Plot:</span>
            <select
              value={selectedPlotId}
              onChange={(e) => setSelectedPlotId(e.target.value)}
              className="bg-slate-50 text-slate-900 font-bold text-xs rounded-xl px-2.5 py-1.5 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
            >
              {PLOTS.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          <div className="bg-white px-4 py-2 rounded-2xl border border-slate-200/80 flex items-center space-x-3 shadow-xs">
            <Sun className="w-5 h-5 text-amber-500" />
            <div>
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Weather</div>
              <div className="font-bold text-slate-800 text-xs">26°C, Clear Sky</div>
            </div>
          </div>
        </div>
      </div>

      {/* ================= 1. DAILY ACTION BANNER ================= */}
      <DailyActionBanner />

      {/* ================= 2. FARMER MODE SIMPLIFIED OPERATIONAL CARDS ================= */}
      {isFarmer ? (
        <div className="space-y-6">
          
          {/* 4 Big Operational Status Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Card 1: Soil Water Status */}
            <div className="bg-white/95 rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="p-3 bg-sky-50 text-sky-600 rounded-2xl border border-sky-200">
                  <Droplets className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-black bg-emerald-50 text-emerald-800 border border-emerald-200">
                  🟢 Good Moisture
                </span>
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Soil Water Status</span>
                <div className="text-3xl font-black text-slate-900 mt-0.5">{soil.soilMoisture ?? 48}%</div>
                <p className="text-xs text-slate-500 font-medium mt-1">
                  Optimal range: 45% &ndash; 60%
                </p>
              </div>
              <button
                onClick={handleQuickWater}
                className={`w-full py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer shadow-xs active:scale-95 flex items-center justify-center space-x-1.5 ${
                  isDripOn
                    ? 'bg-sky-600 text-white animate-pulse'
                    : 'bg-slate-100 hover:bg-sky-50 text-slate-700 hover:text-sky-700 border border-slate-200'
                }`}
              >
                <Droplets className="w-3.5 h-3.5" />
                <span>{isDripOn ? `Watering... (${Math.floor(wateringTimer/60)}m left)` : 'Water Plot for 15m'}</span>
              </button>
            </div>

            {/* Card 2: Temperature & Climate Comfort */}
            <div className="bg-white/95 rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="p-3 bg-rose-50 text-rose-600 rounded-2xl border border-rose-200">
                  <Thermometer className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-black bg-emerald-50 text-emerald-800 border border-emerald-200">
                  🟢 Comfortable
                </span>
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Air Temperature</span>
                <div className="text-3xl font-black text-slate-900 mt-0.5">{env.airTemp ?? 24}°C</div>
                <p className="text-xs text-slate-500 font-medium mt-1">
                  Target: 22°C &ndash; 26°C
                </p>
              </div>
              <button
                onClick={handleQuickFan}
                className={`w-full py-2.5 rounded-xl text-xs font-black transition-all cursor-pointer shadow-xs active:scale-95 flex items-center justify-center space-x-1.5 ${
                  isFanOn
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200'
                }`}
              >
                <Wind className="w-3.5 h-3.5" />
                <span>{isFanOn ? 'Shade Fans Running' : 'Turn On Shade Fans'}</span>
              </button>
            </div>

            {/* Card 3: Crop Growth Pace */}
            <div className="bg-white/95 rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl border border-emerald-200">
                  <Sprout className="w-6 h-6" />
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-black bg-emerald-50 text-emerald-800 border border-emerald-200">
                  🟢 On Schedule
                </span>
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Growth Pace</span>
                <div className="text-3xl font-black text-slate-900 mt-0.5">Day 42 <span className="text-xs text-slate-500 font-medium">of 75</span></div>
                <p className="text-xs text-slate-500 font-medium mt-1">
                  Flowering &bull; Estimated harvest in ~33 days
                </p>
              </div>
              <div className="pt-2">
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: '56%' }} />
                </div>
              </div>
            </div>

            {/* Card 4: AI Crop Health Score */}
            <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-3xl p-6 shadow-md flex flex-col justify-between space-y-3">
              <div className="flex items-center justify-between">
                <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md">
                  <Zap className="w-6 h-6 text-amber-300" />
                </div>
                <span className="px-2.5 py-1 rounded-full text-xs font-black bg-white/20 border border-white/30 text-white">
                  95% Optimal
                </span>
              </div>
              <div>
                <span className="text-xs font-bold text-emerald-100 uppercase tracking-wider">Overall Health Score</span>
                <div className="text-3xl font-black mt-0.5">Excellent</div>
                <p className="text-xs text-emerald-100 font-medium mt-1">
                  Zero thermal or fungal stress detected
                </p>
              </div>
              <div className="text-[11px] font-bold text-emerald-100 bg-black/15 p-2 rounded-xl text-center">
                All micro-climate thresholds in green zone
              </div>
            </div>

          </div>
        </div>
      ) : (
        /* ================= 3. AGRONOMIST MODE (DEEP SCIENTIFIC & GDD ENGINE) ================= */
        <div className="space-y-6">
          {/* Hero Phenological Stage & GDD Tracker Card */}
          <CropGrowthTracker
            plotId={selectedPlotId}
            currentTemp={typeof env.airTemp === 'number' ? env.airTemp : 25}
            cropName={selectedPlotObj.name}
          />

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content: Categorized Telemetry Grid */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-sm border border-slate-200/80 space-y-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-extrabold text-slate-900 flex items-center">
                    <Activity className="w-5 h-5 mr-2 text-sky-600" />
                    Biophysical Sensor Grid ({selectedPlotObj.crop})
                  </h3>
                  <button
                    onClick={() => setShowAllParams(!showAllParams)}
                    className="text-xs font-bold text-sky-700 hover:text-sky-800 bg-sky-50 hover:bg-sky-100 px-3.5 py-1.5 rounded-xl border border-sky-200 transition-all cursor-pointer shadow-xs"
                  >
                    {showAllParams ? 'Show Key Parameters Only' : 'Show All Scientific Parameters (+12)'}
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div className="bg-slate-50/80 rounded-2xl p-4 text-center border border-slate-200/70">
                    <div className="text-xs text-slate-500 font-semibold mb-1">Air Temp</div>
                    <div className="font-black text-slate-900 text-lg">{env.airTemp ?? 24.2} °C</div>
                  </div>
                  <div className="bg-slate-50/80 rounded-2xl p-4 text-center border border-slate-200/70">
                    <div className="text-xs text-slate-500 font-semibold mb-1">Soil Moisture</div>
                    <div className="font-black text-slate-900 text-lg">{soil.soilMoisture ?? 48} %</div>
                  </div>
                  <div className="bg-slate-50/80 rounded-2xl p-4 text-center border border-slate-200/70">
                    <div className="text-xs text-slate-500 font-semibold mb-1">VPD</div>
                    <div className="font-black text-slate-900 text-lg">1.05 kPa</div>
                  </div>
                  <div className="bg-slate-50/80 rounded-2xl p-4 text-center border border-slate-200/70">
                    <div className="text-xs text-slate-500 font-semibold mb-1">Soil pH</div>
                    <div className="font-black text-slate-900 text-lg">{soil.soilPh ?? 6.5}</div>
                  </div>
                  <div className="bg-slate-50/80 rounded-2xl p-4 text-center border border-slate-200/70">
                    <div className="text-xs text-slate-500 font-semibold mb-1">Nitrogen</div>
                    <div className="font-black text-slate-900 text-lg">{soil.nitrogen ?? 45} mg/kg</div>
                  </div>
                  <div className="bg-slate-50/80 rounded-2xl p-4 text-center border border-slate-200/70">
                    <div className="text-xs text-slate-500 font-semibold mb-1">Solar PAR</div>
                    <div className="font-black text-slate-900 text-lg">620 W/m²</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar content: AI Advisor & Alerts */}
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-3xl p-6 text-white shadow-md">
                <h3 className="text-base font-bold mb-4 flex items-center text-emerald-50">
                  <Zap className="w-5 h-5 mr-2 text-amber-300" />
                  Agronomy Diagnostic
                </h3>
                {aiAdvisory && (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center border-b border-white/20 pb-4">
                      <div>
                        <div className="text-[11px] text-emerald-100 uppercase font-bold">Health Score</div>
                        <div className="text-3xl font-black">{aiAdvisory.healthScore}%</div>
                      </div>
                      <div>
                        <div className="text-[11px] text-emerald-100 uppercase font-bold">Yield Potential</div>
                        <div className="text-3xl font-black">{aiAdvisory.yieldPotential}%</div>
                      </div>
                    </div>
                    <p className="text-xs leading-relaxed font-medium text-emerald-50">
                      {aiAdvisory.recommendations?.[0]?.solution || 'Micro-climate parameters are within optimal agronomic thresholds.'}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
