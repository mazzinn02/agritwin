import React, { useState, useEffect } from 'react';
import { ref, onValue, set } from '../lib/firebase';
import { db } from '../lib/firebase';
import { Activity, Plus, BatteryMedium, Wifi } from 'lucide-react';

const DEFAULT_SENSORS: Record<string, any> = {
  'SENS_TEMP_1': { id: 'SENS_TEMP_1', type: 'Air Temp & Humidity', location: 'Plot 1 - Canopy', status: 'Active', battery: '85%', pollingInterval: 30, powerSave: false },
  'SENS_SOIL_1': { id: 'SENS_SOIL_1', type: 'Soil Moisture & Temp', location: 'Plot 1 - Root Zone', status: 'Active', battery: '92%', pollingInterval: 30, powerSave: false },
  'SENS_LIGHT_1': { id: 'SENS_LIGHT_1', type: 'PAR Light Sensor', location: 'Plot 1 - Top', status: 'Active', battery: '100%', pollingInterval: 60, powerSave: false },
  'SENS_NPK_1': { id: 'SENS_NPK_1', type: 'Soil NPK & pH', location: 'Plot 1 - Substrate', status: 'Active', battery: '78%', pollingInterval: 300, powerSave: true }
};

export const MySensors = () => {
  const [sensorsMap, setSensorsMap] = useState<Record<string, any>>({});
  const [showAddModal, setShowAddModal] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState<any>(null);

  // Config modal local form states
  const [pollingInterval, setPollingInterval] = useState(30);
  const [powerSave, setPowerSave] = useState(false);

  useEffect(() => {
    const sensorsRef = ref(db, 'sensors');
    const unsubscribe = onValue(sensorsRef, (snapshot) => {
      if (snapshot.exists()) {
        setSensorsMap(snapshot.val());
      } else {
        set(ref(db, 'sensors'), DEFAULT_SENSORS);
        setSensorsMap(DEFAULT_SENSORS);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleAddSensor = async (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const newId = (formData.get('id') as string).trim();
    if (!newId) return;

    const newSensor = {
      id: newId,
      type: (formData.get('type') as string).trim(),
      location: (formData.get('location') as string).trim(),
      status: 'Active',
      battery: '100%',
      pollingInterval: 30,
      powerSave: false
    };

    await set(ref(db, `sensors/${newId}`), newSensor);
    setShowAddModal(false);
  };

  const openConfig = (sensor: any) => {
    setShowConfigModal(sensor);
    setPollingInterval(sensor.pollingInterval || 30);
    setPowerSave(!!sensor.powerSave);
  };

  const handleSaveConfig = async () => {
    if (!showConfigModal) return;
    const updated = {
      ...showConfigModal,
      pollingInterval: Number(pollingInterval),
      powerSave: powerSave
    };
    await set(ref(db, `sensors/${showConfigModal.id}`), updated);
    setShowConfigModal(null);
  };

  const sensorsList = Object.values(sensorsMap);

  return (
    <div className="space-y-6 text-slate-800">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 flex items-center">
            <Activity className="mr-3 text-sky-600 w-8 h-8" />
            Sensor Hardware Fleet
          </h2>
          <p className="text-slate-500 text-sm mt-1 font-medium">Manage wireless sensor nodes, battery telemetry, and edge polling intervals</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)} 
          className="flex items-center px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white font-extrabold rounded-xl text-xs uppercase tracking-wider transition-all shadow-xs cursor-pointer active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Sensor
        </button>
      </div>

      <div className="bg-white/95 backdrop-blur-sm rounded-3xl shadow-sm border border-slate-200/80 overflow-hidden">
        <table className="w-full text-left border-collapse text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold uppercase tracking-wider border-b border-slate-200">
            <tr>
              <th className="p-4">Sensor ID</th>
              <th className="p-4">Type</th>
              <th className="p-4">Location</th>
              <th className="p-4">Status</th>
              <th className="p-4">Battery</th>
              <th className="p-4">Polling</th>
              <th className="p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
            {sensorsList.map((sensor: any) => (
              <tr key={sensor.id} className="hover:bg-slate-50/80 transition-colors">
                <td className="p-4 font-mono font-bold text-slate-900">{sensor.id}</td>
                <td className="p-4">{sensor.type}</td>
                <td className="p-4">{sensor.location}</td>
                <td className="p-4">
                  <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold ${
                    sensor.status === 'Active' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'
                  }`}>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mr-1.5" />
                    {sensor.status}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex items-center space-x-1.5">
                    <BatteryMedium className="w-4 h-4 text-emerald-600" />
                    <span className="font-bold text-slate-900">{sensor.battery || '90%'}</span>
                  </div>
                </td>
                <td className="p-4 font-mono">{sensor.pollingInterval || 30}s</td>
                <td className="p-4 text-right">
                  <button
                    onClick={() => openConfig(sensor)}
                    className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold cursor-pointer transition-colors"
                  >
                    Configure
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add Sensor Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <form onSubmit={handleAddSensor} className="bg-white border border-slate-200 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-slate-900">Provision New Sensor Node</h3>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">Sensor ID</label>
              <input name="id" placeholder="e.g. SENS_TEMP_2" required className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">Type</label>
              <input name="type" placeholder="e.g. Soil Moisture & Temp" required className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500" />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">Location</label>
              <input name="location" placeholder="e.g. Plot 2 - Canopy" required className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500" />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer">Cancel</button>
              <button type="submit" className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold cursor-pointer">Save Sensor</button>
            </div>
          </form>
        </div>
      )}

      {/* Config Modal */}
      {showConfigModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-lg font-black text-slate-900">Configure {showConfigModal.id}</h3>
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">Telemetry Polling Interval (seconds)</label>
              <input 
                type="number" 
                value={pollingInterval} 
                onChange={e => setPollingInterval(Number(e.target.value))} 
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500" 
              />
            </div>
            <div className="flex items-center space-x-2">
              <input 
                type="checkbox" 
                id="powersave" 
                checked={powerSave} 
                onChange={e => setPowerSave(e.target.checked)} 
                className="w-4 h-4 text-sky-600 rounded cursor-pointer"
              />
              <label htmlFor="powersave" className="text-xs font-bold text-slate-700 cursor-pointer">Enable Low-Power Edge Sleep Mode</label>
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <button onClick={() => setShowConfigModal(null)} className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer">Cancel</button>
              <button onClick={handleSaveConfig} className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold cursor-pointer">Apply Configuration</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MySensors;
