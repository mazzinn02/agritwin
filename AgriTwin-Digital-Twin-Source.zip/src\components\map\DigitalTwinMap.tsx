import React, { useState, useEffect, useRef } from 'react';
import { 
  Layers, 
  Sparkles, 
  Droplets, 
  Thermometer, 
  Radio, 
  Activity, 
  Ruler, 
  Sprout, 
  Scale, 
  Settings2, 
  LineChart, 
  X, 
  Maximize2,
  Check,
  ChevronRight,
  Sun,
  Eye,
  MapPin,
  Bot,
  Droplet
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { computeGrowthStatus } from '../../lib/gdd-calculator';
import PlantCanopySvg from '../common/PlantCanopySvg';
import { useUserMode } from '../../context/UserModeContext';
import { ref, set } from '../../lib/firebase';
import { db } from '../../lib/firebase';

export const IIIT_DHARWAD_CENTER = { lat: 15.4589, lng: 75.0078 };

export interface PlotPolygonConfig {
  id: string;
  name: string;
  crop: string;
  variety: string;
  cropType: string;
  center: [number, number];
  polygonCoordinates: [number, number][];
  healthScore: number;
  healthStatus: 'Excellent' | 'Good' | 'Needs Attention' | 'Critical';
  soilMoisture: number;
  airTemp: number;
  humidity: number;
  soilPh: number;
  nitrogen: number;
  vpd: number;
  yieldForecastKg: number;
  irrigationStatus: 'Active' | 'Standby';
  sensorsCount: number;
}

export const PLOT_POLYGONS: PlotPolygonConfig[] = [
  {
    id: 'plot_1',
    name: 'Plot 1: Tomato Bed',
    crop: 'Tomato',
    variety: 'Sarpan F1-STH-520',
    cropType: 'tomato',
    center: [15.4592, 75.0075],
    polygonCoordinates: [
      [15.45945, 75.00725],
      [15.45945, 75.00775],
      [15.45895, 75.00775],
      [15.45895, 75.00725]
    ],
    healthScore: 95,
    healthStatus: 'Excellent',
    soilMoisture: 48,
    airTemp: 24.2,
    humidity: 62,
    soilPh: 6.5,
    nitrogen: 45,
    vpd: 1.05,
    yieldForecastKg: 450,
    irrigationStatus: 'Active',
    sensorsCount: 4
  },
  {
    id: 'plot_2',
    name: 'Plot 2: Lettuce Bed',
    crop: 'Lettuce',
    variety: 'Butterhead Green',
    cropType: 'lettuce',
    center: [15.4592, 75.0082],
    polygonCoordinates: [
      [15.45945, 75.00795],
      [15.45945, 75.00845],
      [15.45895, 75.00845],
      [15.45895, 75.00795]
    ],
    healthScore: 78,
    healthStatus: 'Needs Attention',
    soilMoisture: 52,
    airTemp: 22.5,
    humidity: 68,
    soilPh: 6.2,
    nitrogen: 50,
    vpd: 0.88,
    yieldForecastKg: 320,
    irrigationStatus: 'Standby',
    sensorsCount: 3
  },
  {
    id: 'plot_3',
    name: 'Plot 3: Pepper Bed',
    crop: 'Pepper',
    variety: 'Bell Pepper Red',
    cropType: 'pepper',
    center: [15.4586, 75.0082],
    polygonCoordinates: [
      [15.45885, 75.00795],
      [15.45885, 75.00845],
      [15.45835, 75.00845],
      [15.45835, 75.00795]
    ],
    healthScore: 90,
    healthStatus: 'Good',
    soilMoisture: 42,
    airTemp: 26.1,
    humidity: 56,
    soilPh: 6.8,
    nitrogen: 40,
    vpd: 1.25,
    yieldForecastKg: 410,
    irrigationStatus: 'Standby',
    sensorsCount: 4
  },
  {
    id: 'plot_4',
    name: 'Plot 4: Strawberry Bed',
    crop: 'Strawberry',
    variety: 'Chandler Sweet',
    cropType: 'strawberry',
    center: [15.4586, 75.0075],
    polygonCoordinates: [
      [15.45885, 75.00725],
      [15.45885, 75.00775],
      [15.45835, 75.00775],
      [15.45835, 75.00725]
    ],
    healthScore: 92,
    healthStatus: 'Good',
    soilMoisture: 50,
    airTemp: 23.4,
    humidity: 59,
    soilPh: 6.4,
    nitrogen: 42,
    vpd: 1.12,
    yieldForecastKg: 380,
    irrigationStatus: 'Standby',
    sensorsCount: 3
  }
];

export type MapTileStyle = 'roadmap' | 'satellite' | 'terrain';

const TILE_URLS: Record<MapTileStyle, { url: string; maxZoom: number; attribution: string }> = {
  roadmap: {
    url: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
    maxZoom: 19,
    attribution: 'CartoDB Light Positron'
  },
  satellite: {
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    maxZoom: 19,
    attribution: 'Esri World Imagery'
  },
  terrain: {
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    maxZoom: 17,
    attribution: 'OpenTopoMap'
  }
};

export const DigitalTwinMap: React.FC = () => {
  const navigate = useNavigate();
  const { isFarmer } = useUserMode();
  const [selectedPlotId, setSelectedPlotId] = useState<string | null>('plot_1');
  const [tileStyle, setTileStyle] = useState<MapTileStyle>('roadmap');

  const [layerPolygons, setLayerPolygons] = useState(true);
  const [layerHeatmap, setLayerHeatmap] = useState(true);
  const [layerTemp, setLayerTemp] = useState(true);
  const [layerSensors, setLayerSensors] = useState(true);

  const [mapLoading, setMapLoading] = useState(true);
  const [mapError, setMapError] = useState<string | null>(null);
  const [wateringTriggered, setWateringTriggered] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const tileLayerRef = useRef<any>(null);
  const polygonLayersRef = useRef<any[]>([]);
  const markerLayersRef = useRef<any[]>([]);
  const heatmapLayersRef = useRef<any[]>([]);

  const selectedPlot = PLOT_POLYGONS.find(p => p.id === selectedPlotId) || null;
  const growth = computeGrowthStatus(selectedPlotId || 'plot_1');

  const getPlotColors = (healthScore: number, isSelected: boolean) => {
    if (isSelected) {
      return {
        fillColor: '#0284C7',
        fillOpacity: 0.55,
        color: '#0284C7',
        weight: 3.5
      };
    }
    if (healthScore >= 85) {
      return {
        fillColor: '#22C55E',
        fillOpacity: 0.35,
        color: '#16A34A',
        weight: 2
      };
    }
    if (healthScore >= 65) {
      return {
        fillColor: '#F59E0B',
        fillOpacity: 0.35,
        color: '#D97706',
        weight: 2
      };
    }
    return {
      fillColor: '#EF4444',
      fillOpacity: 0.35,
      color: '#DC2626',
      weight: 2
    };
  };

  useEffect(() => {
    let isMounted = true;

    const loadLeaflet = () => {
      if ((window as any).L) {
        if (isMounted) initLeafletMap();
        return;
      }

      if (!document.getElementById('leaflet-css')) {
        const link = document.createElement('link');
        link.id = 'leaflet-css';
        link.rel = 'stylesheet';
        link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        document.head.appendChild(link);
      }

      if (!document.getElementById('leaflet-js')) {
        const script = document.createElement('script');
        script.id = 'leaflet-js';
        script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
        script.onload = () => {
          if (isMounted) initLeafletMap();
        };
        script.onerror = () => {
          if (isMounted) {
            setMapError('Failed to load map engine.');
            setMapLoading(false);
          }
        };
        document.head.appendChild(script);
      } else {
        const timer = setInterval(() => {
          if ((window as any).L) {
            clearInterval(timer);
            if (isMounted) initLeafletMap();
          }
        }, 100);
      }
    };

    const initLeafletMap = () => {
      if (!containerRef.current || mapInstanceRef.current) return;
      const L = (window as any).L;
      if (!L) return;

      try {
        const map = L.map(containerRef.current, {
          center: [IIIT_DHARWAD_CENTER.lat, IIIT_DHARWAD_CENTER.lng],
          zoom: 17,
          zoomControl: false,
          attributionControl: false
        });

        L.control.zoom({ position: 'topleft' }).addTo(map);

        const currentTile = TILE_URLS[tileStyle];
        const tileLayer = L.tileLayer(currentTile.url, {
          maxZoom: currentTile.maxZoom,
          subdomains: 'abcd'
        }).addTo(map);

        tileLayerRef.current = tileLayer;
        mapInstanceRef.current = map;

        setTimeout(() => {
          map.invalidateSize();
          setMapLoading(false);
        }, 200);
      } catch (err: any) {
        setMapError(err.message || 'Map initialization error');
        setMapLoading(false);
      }
    };

    loadLeaflet();

    return () => {
      isMounted = false;
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const map = mapInstanceRef.current;
    const L = (window as any).L;
    if (!map || !L || !tileLayerRef.current) return;

    map.removeLayer(tileLayerRef.current);
    const newTileConfig = TILE_URLS[tileStyle];
    const newLayer = L.tileLayer(newTileConfig.url, {
      maxZoom: newTileConfig.maxZoom,
      subdomains: 'abcd'
    }).addTo(map);
    tileLayerRef.current = newLayer;
  }, [tileStyle]);

  useEffect(() => {
    const map = mapInstanceRef.current;
    const L = (window as any).L;
    if (!map || !L) return;

    polygonLayersRef.current.forEach(p => map.removeLayer(p));
    polygonLayersRef.current = [];

    markerLayersRef.current.forEach(m => map.removeLayer(m));
    markerLayersRef.current = [];

    heatmapLayersRef.current.forEach(h => map.removeLayer(h));
    heatmapLayersRef.current = [];

    PLOT_POLYGONS.forEach(plot => {
      const isSelected = plot.id === selectedPlotId;
      const styling = getPlotColors(plot.healthScore, isSelected);

      if (layerPolygons) {
        const polygon = L.polygon(plot.polygonCoordinates, {
          fillColor: styling.fillColor,
          fillOpacity: styling.fillOpacity,
          color: styling.color,
          weight: styling.weight,
          className: 'cursor-pointer'
        }).addTo(map);

        polygon.bindTooltip(`
          <div style="font-family: sans-serif; font-size: 11px; padding: 2px;">
            <b style="color: #0f172a;">${plot.name}</b><br/>
            <span style="color: #475569;">${plot.crop} (${plot.variety})</span><br/>
            <span style="color: #0284c7; font-weight: bold;">Health: ${plot.healthScore}%</span>
          </div>
        `, {
          direction: 'top',
          className: 'custom-leaflet-tooltip'
        });

        polygon.on('click', () => {
          setSelectedPlotId(plot.id);
          map.panTo(plot.center);
        });

        polygonLayersRef.current.push(polygon);
      }

      if (layerHeatmap) {
        const moistureRatio = plot.soilMoisture / 100;
        const heatCircle = L.circle(plot.center, {
          radius: 28,
          fillColor: '#0284C7',
          fillOpacity: 0.15 + moistureRatio * 0.25,
          color: '#38BDF8',
          weight: 1,
          dashArray: '3, 4'
        }).addTo(map);

        heatmapLayersRef.current.push(heatCircle);
      }

      if (layerTemp) {
        const tempIcon = L.divIcon({
          className: 'custom-temp-badge',
          html: `
            <div style="transform: translate(-50%, -50%); display: flex; align-items: center; background: rgba(255,255,255,0.95); border: 1.5px solid #F59E0B; border-radius: 9999px; padding: 2px 8px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); font-size: 10px; font-weight: 800; color: #92400E; white-space: nowrap;">
              <span style="color: #D97706; margin-right: 3px;">🌡</span> ${plot.airTemp}°C
            </div>
          `,
          iconSize: [60, 24],
          iconAnchor: [30, 12]
        });

        const tempMarker = L.marker(plot.center, { icon: tempIcon }).addTo(map);
        markerLayersRef.current.push(tempMarker);
      }

      if (layerSensors) {
        const isOptimal = plot.healthScore >= 85;
        const badgeColor = isOptimal ? '#10B981' : '#F59E0B';

        const hardwareIcon = L.divIcon({
          className: 'custom-hardware-marker',
          html: `
            <div style="transform: translate(-50%, -100%); cursor: pointer;" class="group">
              <div style="position: relative; display: flex; align-items: center; justify-content: center;">
                <span style="position: absolute; inset: -4px; border-radius: 9999px; background: ${badgeColor}; opacity: 0.6;" class="animate-ping"></span>
                <div style="position: relative; width: 32px; height: 32px; border-radius: 9999px; background: ${badgeColor}; border: 2.5px solid #ffffff; box-shadow: 0 4px 6px rgba(0,0,0,0.2); display: flex; align-items: center; justify-content: center; color: white;">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                </div>
              </div>
              <div style="position: absolute; top: 34px; left: 50%; transform: translateX(-50%); background: #ffffff; border: 1px solid #e2e8f0; color: #0f172a; font-size: 10px; font-weight: 800; padding: 2px 6px; border-radius: 6px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); white-space: nowrap;">
                ${plot.crop}
              </div>
            </div>
          `,
          iconSize: [36, 48],
          iconAnchor: [18, 48]
        });

        const sensorMarker = L.marker([plot.center[0] + 0.0001, plot.center[1] - 0.0001], { icon: hardwareIcon }).addTo(map);
        sensorMarker.on('click', () => {
          setSelectedPlotId(plot.id);
          map.panTo(plot.center);
        });

        markerLayersRef.current.push(sensorMarker);
      }
    });
  }, [selectedPlotId, layerPolygons, layerHeatmap, layerTemp, layerSensors, mapLoading]);

  const handleFarmerWaterNow = async () => {
    if (!selectedPlot) return;
    setWateringTriggered(true);
    await set(ref(db, `devices/${selectedPlot.id}/irrigation`), {
      enabled: true,
      mode: 'manual',
      autoOffAt: Date.now() + 15 * 60 * 1000
    });
    setTimeout(() => setWateringTriggered(false), 3000);
  };

  return (
    <div className="space-y-6 text-slate-800 font-sans">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 flex items-center">
            <Layers className="mr-3 text-sky-600 w-8 h-8" />
            Geospatial Digital Twin Map
          </h2>
          <p className="text-slate-500 text-sm mt-1 font-medium">
            {isFarmer 
              ? 'Color-coded field map: Green = Good, Yellow = Needs Water. Tap any field to water.' 
              : 'Vector field polygons, real-time biophysical overlays, and sensor telemetry anchored near IIIT Dharwad campus'}
          </p>
        </div>
      </div>

      <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 shadow-sm border border-slate-200/80 relative">
        <div className="relative h-[620px] w-full rounded-2xl overflow-hidden border border-slate-200 shadow-inner">
          <div ref={containerRef} className="h-full w-full select-none" />

          {mapLoading && (
            <div className="absolute inset-0 bg-slate-50/80 backdrop-blur-xs flex items-center justify-center font-bold text-slate-600 text-xs z-30">
              Initializing Geospatial Map Engine...
            </div>
          )}

          {/* Floating Layer Control HUD (Top-Right) */}
          <div className="absolute top-4 right-4 z-[400] bg-white/95 backdrop-blur-md p-4 rounded-2xl border border-slate-200/90 shadow-xl w-68 space-y-4">
            <div>
              <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block mb-2">Map View Type</span>
              <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
                {(['roadmap', 'satellite', 'terrain'] as const).map(style => (
                  <button
                    key={style}
                    onClick={() => setTileStyle(style)}
                    className={`py-1 rounded-lg text-xs font-extrabold capitalize transition-all cursor-pointer ${
                      tileStyle === style 
                        ? 'bg-white text-sky-700 shadow-xs' 
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    {style === 'roadmap' ? 'Road' : style === 'satellite' ? 'Aerial' : 'Terrain'}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100">
              <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">Active GIS Overlays</span>

              <label className="flex items-center justify-between p-1.5 rounded-xl hover:bg-slate-50 cursor-pointer select-none">
                <span className="flex items-center space-x-2 text-xs font-bold text-slate-700">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Crop Health Polygons</span>
                </span>
                <input 
                  type="checkbox" 
                  checked={layerPolygons} 
                  onChange={e => setLayerPolygons(e.target.checked)} 
                  className="w-4 h-4 text-emerald-600 rounded cursor-pointer accent-emerald-600"
                />
              </label>

              <label className="flex items-center justify-between p-1.5 rounded-xl hover:bg-slate-50 cursor-pointer select-none">
                <span className="flex items-center space-x-2 text-xs font-bold text-slate-700">
                  <Droplets className="w-3.5 h-3.5 text-sky-600" />
                  <span>Soil Moisture Heatmap</span>
                </span>
                <input 
                  type="checkbox" 
                  checked={layerHeatmap} 
                  onChange={e => setLayerHeatmap(e.target.checked)} 
                  className="w-4 h-4 text-sky-600 rounded cursor-pointer accent-sky-600"
                />
              </label>

              <label className="flex items-center justify-between p-1.5 rounded-xl hover:bg-slate-50 cursor-pointer select-none">
                <span className="flex items-center space-x-2 text-xs font-bold text-slate-700">
                  <Thermometer className="w-3.5 h-3.5 text-amber-600" />
                  <span>Temperature Overlays</span>
                </span>
                <input 
                  type="checkbox" 
                  checked={layerTemp} 
                  onChange={e => setLayerTemp(e.target.checked)} 
                  className="w-4 h-4 text-amber-600 rounded cursor-pointer accent-amber-600"
                />
              </label>

              <label className="flex items-center justify-between p-1.5 rounded-xl hover:bg-slate-50 cursor-pointer select-none">
                <span className="flex items-center space-x-2 text-xs font-bold text-slate-700">
                  <Radio className="w-3.5 h-3.5 text-purple-600" />
                  <span>Device & Sensor Markers</span>
                </span>
                <input 
                  type="checkbox" 
                  checked={layerSensors} 
                  onChange={e => setLayerSensors(e.target.checked)} 
                  className="w-4 h-4 text-purple-600 rounded cursor-pointer accent-purple-600"
                />
              </label>
            </div>

            <div className="pt-2 border-t border-slate-100 space-y-1">
              <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block mb-1">Focus Plot</span>
              <div className="grid grid-cols-2 gap-1.5">
                {PLOT_POLYGONS.map(p => (
                  <button
                    key={p.id}
                    onClick={() => {
                      setSelectedPlotId(p.id);
                      mapInstanceRef.current?.panTo(p.center);
                    }}
                    className={`px-2 py-1.5 rounded-xl text-[11px] font-bold border transition-all truncate cursor-pointer ${
                      selectedPlotId === p.id 
                        ? 'bg-sky-50 text-sky-800 border-sky-300 shadow-xs' 
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {p.crop} ({p.id})
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Slide-Out Detail Panel / Farmer 3-Button Drawer */}
          {selectedPlot && (
            <div className="absolute bottom-4 left-4 z-[400] bg-white/95 backdrop-blur-md rounded-3xl p-6 border border-slate-200/90 shadow-2xl max-w-sm sm:max-w-md w-full animate-fadeIn space-y-4">
              
              <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-lg font-black text-slate-900">{selectedPlot.crop}</h3>
                    <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {selectedPlot.healthStatus}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    {selectedPlot.variety} &bull; <strong className="text-sky-700">{selectedPlot.id}</strong>
                  </p>
                </div>

                <button
                  onClick={() => setSelectedPlotId(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Status summary */}
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-2xl border border-slate-200/70">
                <div className="flex items-center space-x-3">
                  <div className="p-2.5 rounded-xl bg-white border border-slate-200 text-sky-600 shadow-xs">
                    <Sprout className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 font-bold uppercase">Growth Phase</div>
                    <div className="text-xs font-black text-slate-900">{growth.currentStage.label} (Day {growth.dap})</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[10px] text-slate-400 font-bold uppercase">Health Index</div>
                  <div className="text-base font-black text-emerald-700">{selectedPlot.healthScore}%</div>
                </div>
              </div>

              {/* 3 Big Farmer-Friendly Action Buttons */}
              <div className="grid grid-cols-3 gap-2 pt-1">
                <button
                  onClick={() => navigate('/virtual-farm')}
                  className="flex flex-col items-center justify-center p-3 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-2xl border border-emerald-200 text-xs font-black transition-all shadow-xs cursor-pointer active:scale-95 text-center"
                >
                  <Sparkles className="w-5 h-5 text-emerald-600 mb-1" />
                  <span>View Health</span>
                </button>

                <button
                  onClick={handleFarmerWaterNow}
                  className={`flex flex-col items-center justify-center p-3 rounded-2xl text-xs font-black transition-all shadow-xs cursor-pointer active:scale-95 text-center ${
                    wateringTriggered
                      ? 'bg-sky-600 text-white animate-pulse'
                      : 'bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200'
                  }`}
                >
                  <Droplet className="w-5 h-5 text-sky-600 mb-1" />
                  <span>{wateringTriggered ? 'Watering...' : 'Water Now (15m)'}</span>
                </button>

                <button
                  onClick={() => navigate('/advisor')}
                  className="flex flex-col items-center justify-center p-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-xs font-black transition-all shadow-xs cursor-pointer active:scale-95 text-center"
                >
                  <Bot className="w-5 h-5 text-amber-300 mb-1" />
                  <span>Ask AI Doctor</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DigitalTwinMap;
