import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Sprout, 
  History, 
  LineChart, 
  BrainCircuit, 
  Map, 
  Camera, 
  Activity, 
  Settings2, 
  GitCompare,
  Grid,
  Sliders,
  ChevronDown,
  ChevronRight,
  Leaf,
  FolderKanban
} from 'lucide-react';

const primaryItems = [
  { name: 'Dashboard', path: '/', icon: LayoutDashboard },
  { name: 'Crop Vision', path: '/vision', icon: Sprout },
  { name: 'Field Log', path: '/history', icon: History },
  { name: 'Analytics', path: '/analytics', icon: LineChart },
  { name: 'AI Advisor', path: '/advisor', icon: BrainCircuit },
  { name: 'Camera Feed', path: '/camera', icon: Camera },
  { name: 'My Sensors', path: '/sensors', icon: Activity },
  { name: 'Device Control', path: '/control', icon: Settings2 },
];

const farmManagementItems = [
  { name: 'Crops', path: '/farm-management/crops', icon: Sprout },
];

const advancedItems = [
  { name: 'What-If Simulator', path: '/what-if', icon: Sliders },
  { name: 'Crop Comparison', path: '/compare', icon: GitCompare },
  { name: 'Virtual Farm', path: '/virtual-farm', icon: Grid },
  { name: 'Map View', path: '/map', icon: Map },
];

export const Sidebar: React.FC = () => {
  const [farmMgmtOpen, setFarmMgmtOpen] = useState(true);
  const [advancedOpen, setAdvancedOpen] = useState(true);

  return (
    <div className="flex flex-col w-64 h-screen bg-white text-slate-700 border-r border-slate-200/80 shadow-xs z-20 select-none shrink-0">
      {/* Brand Logo */}
      <div className="flex items-center space-x-2.5 h-20 border-b border-slate-200/80 px-6">
        <div className="p-2 rounded-xl bg-gradient-to-tr from-emerald-600 to-sky-600 text-white shadow-sm">
          <Leaf className="w-5 h-5" />
        </div>
        <div>
          <h1 className="text-lg font-black tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-emerald-700 via-teal-700 to-sky-700">
            AgriTwin
          </h1>
          <p className="text-[10px] text-slate-500 font-semibold tracking-wider uppercase">Digital Twin OS</p>
        </div>
      </div>

      {/* Nav Menu */}
      <nav className="flex-1 px-4 py-6 space-y-1.5 overflow-y-auto">
        {primaryItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                `flex items-center px-4 py-2.5 rounded-xl transition-all duration-200 ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-xs font-bold'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 font-medium'
                }`
              }
            >
              <Icon className="w-5 h-5 mr-3 shrink-0" />
              <span className="text-sm">{item.name}</span>
            </NavLink>
          );
        })}

        {/* Collapsible Farm Management */}
        <div className="pt-4 mt-4 border-t border-slate-200/80">
          <button
            onClick={() => setFarmMgmtOpen(!farmMgmtOpen)}
            className="w-full flex items-center justify-between px-4 py-2 text-[11px] font-bold text-slate-500 uppercase tracking-wider hover:text-slate-800 transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-1.5">
              <FolderKanban className="w-3.5 h-3.5 text-emerald-600" />
              <span>Farm Management</span>
            </span>
            {farmMgmtOpen ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
          </button>

          {farmMgmtOpen && (
            <div className="mt-1.5 space-y-1 pl-2">
              {farmManagementItems.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.name}
                    to={item.path}
                    className={({ isActive }) =>
                      `flex items-center px-3 py-2 rounded-lg text-xs transition-all duration-200 ${
                        isActive
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold'
                          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 font-medium'
                      }`
                    }
                  >
                    <Icon className="w-4 h-4 mr-2.5 shrink-0 text-emerald-600" />
                    <span>{item.name}</span>
                  </NavLink>
                );
              })}
            </div>
          )}
        </div>

        {/* Collapsible Advanced Tools */}
        <div className="pt-4 mt-2 border-t border-slate-200/80">
          <button
            onClick={() => setAdvancedOpen(!advancedOpen)}
            className="w-full flex items-center justify-between px-4 py-2 text-[11px] font-bold text-slate-500 uppercase tracking-wider hover:text-slate-800 transition-colors cursor-pointer"
          >
            <span>Advanced Tools</span>
            {advancedOpen ? <ChevronDown className="w-4 h-4 text-slate-400" /> : <ChevronRight className="w-4 h-4 text-slate-400" />}
          </button>

          {advancedOpen && (
            <div className="mt-1.5 space-y-1 pl-2">
              {advancedItems.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.name}
                    to={item.path}
                    className={({ isActive }) =>
                      `flex items-center px-3 py-2 rounded-lg text-xs transition-all duration-200 ${
                        isActive
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold'
                          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900 font-medium'
                      }`
                    }
                  >
                    <Icon className="w-4 h-4 mr-2.5 shrink-0" />
                    <span>{item.name}</span>
                  </NavLink>
                );
              })}
            </div>
          )}
        </div>
      </nav>

      {/* Footer Meta */}
      <div className="p-4 border-t border-slate-200/80 text-[11px] text-slate-500 text-center font-medium bg-slate-50/50">
        AgriTwin Platform &bull; Farm Management
      </div>
    </div>
  );
};

export default Sidebar;
