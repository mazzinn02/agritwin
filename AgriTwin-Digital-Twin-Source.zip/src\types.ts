export type ViewMode = 'dashboard' | 'twin' | 'disease' | 'growth' | 'ripeness' | 'yield' | 'sensors' | 'alerts';

export interface CropParameter {
  id: string;
  name: string;
  unit: string;
  currentValue: number;
  targetValue: number;
  status: 'optimal' | 'warning' | 'critical';
  description: string;
  iconName: string;
  color: string;
  historicalData: { time: string; value: number; baseline: number }[];
}

export interface SensorData {
  id: string;
  name: string;
  temperature: number; // °C
  humidity: number; // %
  soilMoisture: number; // %
  sunlightLux: number; // lux
  co2Level: number; // ppm
  lastUpdated: string;
  status: 'online' | 'offline' | 'warning';
}

export interface Alert {
  id: string;
  type: 'disease' | 'growth' | 'moisture' | 'environmental';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: string;
  isRead: boolean;
}

export interface DigitalTwinCropState {
  cropType: string;
  plantingDate: string;
  currentDay: number; // 1-90
  stage: 'Germination' | 'Vegetative' | 'Flowering' | 'Fruit Set' | 'Harvest Ready';
  healthScore: number; // 0 - 100
  plantHeightCm: number; // Parameter 1
  canopyCoveragePercent: number; // Parameter 2
  growthRateCmPerDay: number; // Parameter 3
  diseaseRiskPercent: number; // Parameter 4
  diseaseDetected?: string;
  fruitRipenessPercent: number; // Parameter 5
  estimatedYieldKgPerM2: number; // Parameter 6
  sensors: SensorData;
  alerts: Alert[];
}

export interface AiVisionAnalysisResult {
  plantHeightEstimateCm: number;
  canopyCoveragePercent: number;
  growthStage: string;
  healthAssessment: {
    diseaseName: string;
    riskScore: number;
    severity: 'None' | 'Mild' | 'Moderate' | 'Severe';
    recommendedAction: string;
  };
  fruitRipeness: {
    ripenessPercent: number;
    colorStage: string;
    daysToOptimalHarvest: number;
  };
  yieldProjectionKgPerM2: number;
  confidenceScore: number;
  keyObservations: string[];
}

export interface ArchitectureComponent {
  id: string;
  title: string;
  layer: 'hardware' | 'edge' | 'cloud' | 'digital-twin' | 'web-app';
  icon: string;
  description: string;
  techStack: string[];
  roleInProject: string;
}

export interface PresentationConfig {
  projectTitle: string;
  studentName: string;
  collegeName: string;
  teamMembers: string[];
  clientName: string;
}

