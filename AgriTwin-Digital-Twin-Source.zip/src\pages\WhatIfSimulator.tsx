import React, { useState, useEffect, useMemo } from 'react';
import { ref, onValue } from '../lib/firebase';
import { db } from '../lib/firebase';
import { Sliders, Sparkles, TrendingUp, RotateCcw, Play } from 'lucide-react';

const PLOTS = [
  { id: 'plot_1', name: 'Plot 1: Tomato (Sarpan F1-STH-520)' },
  { id: 'plot_2', name: 'Plot 2: Lettuce (Butterhead Green)' },
  { id: 'plot_3', name: 'Plot 3: Pepper (Bell Pepper Red)' },
  { id: 'plot_4', name: 'Plot 4: Strawberry (Chandler Sweet)' }
];

export const WhatIfSimulator: React.FC = () => {
  const [selectedPlot, setSelectedPlot] = useState('plot_1');
  const [liveReadings, setLiveReadings] = useState<any>(null);
  const [liveAdvisory, setLiveAdvisory] = useState<any>(null);

  // Simulated Slider Controls
  const [simSoilMoisture, setSimSoilMoisture] = useState<number>(52);
  const [simAirTemp, setSimAirTemp] = useState<number>(24);
  const [simNitrogen, setSimNitrogen] = useState<number>(45);
  const [simHumidity, setSimHumidity] = useState<number>(60);
  const [simLight, setSimLight] = useState<number>(45000);
  const [simRunning, setSimRunning] = useState(false);

  useEffect(() => {
    const liveRef = ref(db, `live_readings/${selectedPlot}`);
    const advisoryRef = ref(db, `aiRecommendations/${selectedPlot}`);

    const unsub1 = onValue(liveRef, (snap) => {
      if (snap.exists()) {
        const val = snap.val();
        setLiveReadings(val);
        setSimSoilMoisture(val.soilMoisture ?? 52);
        setSimAirTemp(val.airTemp ?? 24);
        setSimNitrogen(val.nitrogen ?? 45);
        setSimHumidity(val.humidity ?? 60);
        setSimLight(val.light ?? 45000);
      }
    });

    const unsub2 = onValue(advisoryRef, (snap) => {
      if (snap.exists()) {
        setLiveAdvisory(snap.val());
      }
    });

    return () => {
      unsub1();
      unsub2();
    };
  }, [selectedPlot]);

  // Calculate simulated health score & yield potential dynamically
  const simulatedScores = useMemo(() => {
    let health = 95;
    let yieldPot = 92;

    // Soil Moisture (Optimal: 45 - 60%)
    if (simSoilMoisture < 45) {
      const dev = 45 - simSoilMoisture;
      health -= dev * 1.2;
      yieldPot -= dev * 1.4;
    } else if (simSoilMoisture > 60) {
      const dev = simSoilMoisture - 60;
      health -= dev * 0.8;
      yieldPot -= dev * 1.0;
    }

    // Air Temperature (Optimal: 20 - 28°C)
    if (simAirTemp < 20) {
      const dev = 20 - simAirTemp;
      health -= dev * 1.5;
      yieldPot -= dev * 1.8;
    } else if (simAirTemp > 28) {
      const dev = simAirTemp - 28;
      health -= dev * 2.0;
      yieldPot -= dev * 2.2;
    }

    // Nitrogen (Optimal: 40 - 60 mg/kg)
    if (simNitrogen < 40) {
      const dev = 40 - simNitrogen;
      health -= dev * 0.6;
      yieldPot -= dev * 1.2;
    }

    // Humidity (Optimal: 50 - 75%)
    if (simHumidity < 50) {
      const dev = 50 - simHumidity;
      health -= dev * 0.5;
    } else if (simHumidity > 75) {
      const dev = simHumidity - 75;
      health -= dev * 1.0; // Disease risk
    }

    return {
      healthScore: Math.min(100, Math.max(10, Math.round(health))),
      yieldPotential: Math.min(100, Math.max(10, Math.round(yieldPot))),
    };
  }, [simSoilMoisture, simAirTemp, simNitrogen, simHumidity, simLight]);

  const handleResetToLive = () => {
    if (liveReadings) {
      setSimSoilMoisture(liveReadings.soilMoisture ?? 52);
      setSimAirTemp(liveReadings.airTemp ?? 24);
      setSimNitrogen(liveReadings.nitrogen ?? 45);
      setSimHumidity(liveReadings.humidity ?? 60);
      setSimLight(liveReadings.light ?? 45000);
    }
  };

  const handleRunSimulation = () => {
    setSimRunning(true);
    setTimeout(() => setSimRunning(false), 600);
  };

  return (
    <div className="space-y-6 text-slate-800">
      {/* Top Header & Plot Picker */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 flex items-center">
            <Sliders className="mr-3 text-sky-600 w-8 h-8" />
            What-If Scenario Simulator
          </h2>
          <p className="text-slate-500 text-sm mt-1 font-medium">Predict crop health, thermal stress, and yield response under simulated environmental stress</p>
        </div>

        <div className="flex items-center space-x-3">
          <div className="bg-white px-4 py-2 rounded-2xl border border-slate-200 shadow-xs flex items-center space-x-3">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Select Plot:</span>
            <select 
              value={selectedPlot} 
              onChange={(e) => setSelectedPlot(e.target.value)}
              className="bg-slate-50 text-slate-900 text-xs font-bold rounded-xl px-3 py-1.5 border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
            >
              {PLOTS.map(p => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </div>

          <button
            onClick={handleResetToLive}
            className="flex items-center space-x-1.5 px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 font-bold rounded-xl text-xs border border-slate-200 shadow-xs transition-all cursor-pointer active:scale-95"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset</span>
          </button>
        </div>
      </div>

      {/* Outcome Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-3xl p-6 shadow-md flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-emerald-100 uppercase tracking-wider block mb-1">Simulated Health Score</span>
            <div className="text-4xl font-black">{simulatedScores.healthScore}%</div>
            <p className="text-xs text-emerald-100 mt-2 font-medium">
              Baseline: {liveAdvisory?.healthScore ?? 95}% ({simulatedScores.healthScore >= (liveAdvisory?.healthScore ?? 95) ? 'Positive' : 'Degraded'})
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md">
            <Sparkles className="w-8 h-8 text-amber-300" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-sky-600 to-indigo-700 text-white rounded-3xl p-6 shadow-md flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-sky-100 uppercase tracking-wider block mb-1">Projected Yield Potential</span>
            <div className="text-4xl font-black">{simulatedScores.yieldPotential}%</div>
            <p className="text-xs text-sky-100 mt-2 font-medium">
              Baseline: {liveAdvisory?.yieldPotential ?? 90}% ({simulatedScores.yieldPotential >= (liveAdvisory?.yieldPotential ?? 90) ? 'Optimal' : 'Compromised'})
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md">
            <TrendingUp className="w-8 h-8 text-sky-200" />
          </div>
        </div>
      </div>

      {/* Interactive Simulation Sliders Card */}
      <div className="bg-white/95 backdrop-blur-sm p-8 rounded-3xl shadow-sm border border-slate-200/80 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4">
          <h3 className="text-base font-extrabold text-slate-900">Adjust Environmental Levers</h3>
          <button
            onClick={handleRunSimulation}
            disabled={simRunning}
            className="flex items-center space-x-1.5 px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition-all cursor-pointer active:scale-95"
          >
            <Play className="w-3.5 h-3.5" />
            <span>{simRunning ? 'Projecting...' : 'Run Simulation'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Soil Moisture */}
          <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200/70">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-slate-700">Soil Moisture (%)</span>
              <span className="text-sky-700 font-mono">{simSoilMoisture}%</span>
            </div>
            <input 
              type="range" 
              min="10" 
              max="90" 
              value={simSoilMoisture} 
              onChange={e => setSimSoilMoisture(Number(e.target.value))}
              className="w-full accent-sky-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-semibold">
              <span>Dry (10%)</span>
              <span>Optimal (45-60%)</span>
              <span>Saturated (90%)</span>
            </div>
          </div>

          {/* Air Temperature */}
          <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200/70">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-slate-700">Air Temperature (°C)</span>
              <span className="text-amber-700 font-mono">{simAirTemp} °C</span>
            </div>
            <input 
              type="range" 
              min="10" 
              max="45" 
              value={simAirTemp} 
              onChange={e => setSimAirTemp(Number(e.target.value))}
              className="w-full accent-amber-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-semibold">
              <span>Cold (10°C)</span>
              <span>Optimal (20-28°C)</span>
              <span>Extreme Heat (45°C)</span>
            </div>
          </div>

          {/* Nitrogen */}
          <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200/70">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-slate-700">Nitrogen Level (mg/kg)</span>
              <span className="text-emerald-700 font-mono">{simNitrogen} mg/kg</span>
            </div>
            <input 
              type="range" 
              min="10" 
              max="100" 
              value={simNitrogen} 
              onChange={e => setSimNitrogen(Number(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-semibold">
              <span>Depleted (10)</span>
              <span>Optimal (40-60)</span>
              <span>Excess (100)</span>
            </div>
          </div>

          {/* Relative Humidity */}
          <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200/70">
            <div className="flex justify-between text-xs font-bold">
              <span className="text-slate-700">Relative Humidity (%)</span>
              <span className="text-sky-700 font-mono">{simHumidity}%</span>
            </div>
            <input 
              type="range" 
              min="20" 
              max="95" 
              value={simHumidity} 
              onChange={e => setSimHumidity(Number(e.target.value))}
              className="w-full accent-sky-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-semibold">
              <span>Arid (20%)</span>
              <span>Optimal (50-75%)</span>
              <span>Pathogen Risk (95%)</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WhatIfSimulator;
