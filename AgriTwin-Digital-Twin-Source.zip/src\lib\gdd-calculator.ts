export interface CropGddProfile {
  cropId: string;
  name: string;
  botanicalName: string;
  tBase: number; // Base temperature (°C)
  tUpper: number; // Upper cutoff temperature (°C)
  targetMaturityGdd: number; // Total GDD required for full harvest
  stageThresholdsGdd: {
    seedling: number;     // 0 -> seedling max
    vegetative: number;   // seedling -> vegetative max
    flowering: number;    // vegetative -> flowering max
    fruitSet: number;     // flowering -> fruit set max
    harvest: number;      // fruit set -> harvest maturity
  };
  durationDays: number;
}

export const CROP_GDD_PROFILES: Record<string, CropGddProfile> = {
  plot_1: {
    cropId: 'plot_1',
    name: 'Tomato (Sarpan F1-STH-520)',
    botanicalName: 'Solanum lycopersicum',
    tBase: 10.0,
    tUpper: 32.0,
    targetMaturityGdd: 1400,
    stageThresholdsGdd: {
      seedling: 200,
      vegetative: 550,
      flowering: 900,
      fruitSet: 1250,
      harvest: 1400,
    },
    durationDays: 75,
  },
  plot_2: {
    cropId: 'plot_2',
    name: 'Lettuce (Butterhead Green)',
    botanicalName: 'Lactuca sativa',
    tBase: 4.5,
    tUpper: 25.0,
    targetMaturityGdd: 750,
    stageThresholdsGdd: {
      seedling: 120,
      vegetative: 380,
      flowering: 550,
      fruitSet: 650,
      harvest: 750,
    },
    durationDays: 45,
  },
  plot_3: {
    cropId: 'plot_3',
    name: 'Pepper (Bell Pepper Red)',
    botanicalName: 'Capsicum annuum',
    tBase: 10.0,
    tUpper: 35.0,
    targetMaturityGdd: 1350,
    stageThresholdsGdd: {
      seedling: 180,
      vegetative: 520,
      flowering: 880,
      fruitSet: 1200,
      harvest: 1350,
    },
    durationDays: 85,
  },
  plot_4: {
    cropId: 'plot_4',
    name: 'Strawberry (Chandler Sweet)',
    botanicalName: 'Fragaria × ananassa',
    tBase: 7.0,
    tUpper: 28.0,
    targetMaturityGdd: 1100,
    stageThresholdsGdd: {
      seedling: 150,
      vegetative: 450,
      flowering: 750,
      fruitSet: 980,
      harvest: 1100,
    },
    durationDays: 65,
  },
};

export type PhenologicalStageKey = 'seedling' | 'vegetative' | 'flowering' | 'fruitSet' | 'harvest';

export interface PhenologicalStageInfo {
  key: PhenologicalStageKey;
  label: string;
  description: string;
  minGdd: number;
  maxGdd: number;
  stageIndex: number;
}

export const STAGES_ORDER: { key: PhenologicalStageKey; label: string; description: string }[] = [
  { key: 'seedling', label: 'Seedling', description: 'Emergence & early root establishment' },
  { key: 'vegetative', label: 'Vegetative', description: 'Rapid canopy expansion & stem elongation' },
  { key: 'flowering', label: 'Flowering', description: 'Anthesis, bloom & pollination' },
  { key: 'fruitSet', label: 'Fruit Set', description: 'Fruit development & breaker color change' },
  { key: 'harvest', label: 'Harvest Maturity', description: 'Optimal ripeness & harvest window' },
];

/**
 * Standard Daily GDD Equation:
 * GDD = max(0, ((T_max + T_min) / 2) - T_base)
 * with T_upper ceiling cap if specified.
 */
export function calculateDailyGdd(tMax: number, tMin: number, tBase: number, tUpper?: number): number {
  let effMax = tMax;
  let effMin = tMin;

  if (tUpper !== undefined) {
    effMax = Math.min(effMax, tUpper);
    effMin = Math.min(effMin, tUpper);
  }

  const avgTemp = (effMax + effMin) / 2;
  return Math.max(0, +(avgTemp - tBase).toFixed(2));
}

export interface GrowthStatusResult {
  currentStage: PhenologicalStageInfo;
  stageIndex: number; // 0 to 4
  stageCompletionPct: number; // 0 to 100
  totalMaturityPct: number; // 0 to 100
  accumulatedGdd: number;
  targetMaturityGdd: number;
  dap: number; // Days after planting
  totalDurationDays: number;
  daysToNextStage: number;
  dailyGddRate: number;
  stageHealthIndex: 'Ahead of Schedule' | 'On Track' | 'Delayed (Temp Stress)';
  stageHealthColor: string;
  stagesList: (PhenologicalStageInfo & { isCurrent: boolean; isCompleted: boolean; isUpcoming: boolean })[];
}

export function computeGrowthStatus(
  plotId: string,
  currentTemp: number = 24.5,
  simulatedDapOffset?: number
): GrowthStatusResult {
  const profile = CROP_GDD_PROFILES[plotId] || CROP_GDD_PROFILES.plot_1;
  const thresholds = profile.stageThresholdsGdd;

  // Derive realistic DAP and daily rate based on plot
  const defaultDaps: Record<string, number> = {
    plot_1: 42,
    plot_2: 26,
    plot_3: 54,
    plot_4: 38,
  };
  const dap = simulatedDapOffset ?? defaultDaps[plotId] ?? 35;

  // Daily GDD rate based on current temp (e.g. ambient ~24-28C)
  const tMax = currentTemp + 4.5;
  const tMin = currentTemp - 4.5;
  const dailyRate = calculateDailyGdd(tMax, tMin, profile.tBase, profile.tUpper);

  // Accumulated GDD estimation
  const expectedGddPace = dap * (dailyRate || 14.5);
  // Add mild variance
  const accumulatedGdd = Math.min(profile.targetMaturityGdd, +expectedGddPace.toFixed(1));

  // Determine stage boundaries
  const stageRanges: PhenologicalStageInfo[] = [
    { key: 'seedling', label: 'Seedling', description: 'Emergence & early root establishment', minGdd: 0, maxGdd: thresholds.seedling, stageIndex: 0 },
    { key: 'vegetative', label: 'Vegetative', description: 'Canopy expansion & stem elongation', minGdd: thresholds.seedling, maxGdd: thresholds.vegetative, stageIndex: 1 },
    { key: 'flowering', label: 'Flowering', description: 'Anthesis & pollination phase', minGdd: thresholds.vegetative, maxGdd: thresholds.flowering, stageIndex: 2 },
    { key: 'fruitSet', label: 'Fruit Set', description: 'Fruit development & ripening', minGdd: thresholds.flowering, maxGdd: thresholds.fruitSet, stageIndex: 3 },
    { key: 'harvest', label: 'Harvest Maturity', description: 'Optimal harvest readiness', minGdd: thresholds.fruitSet, maxGdd: thresholds.harvest, stageIndex: 4 },
  ];

  let currentStage = stageRanges[0];
  let stageIndex = 0;

  for (let i = 0; i < stageRanges.length; i++) {
    const s = stageRanges[i];
    if (accumulatedGdd >= s.minGdd && (accumulatedGdd < s.maxGdd || i === stageRanges.length - 1)) {
      currentStage = s;
      stageIndex = i;
      break;
    }
  }

  // Calculate completion within current stage
  const stageRangeSpan = currentStage.maxGdd - currentStage.minGdd;
  const stageProgressGdd = Math.max(0, accumulatedGdd - currentStage.minGdd);
  const stageCompletionPct = Math.min(100, Math.max(0, +( (stageProgressGdd / stageRangeSpan) * 100 ).toFixed(1)));

  // Total maturity percentage
  const totalMaturityPct = Math.min(100, +( (accumulatedGdd / profile.targetMaturityGdd) * 100 ).toFixed(1));

  // Days to next stage
  const gddRemainingInStage = Math.max(0, currentStage.maxGdd - accumulatedGdd);
  const daysToNextStage = dailyRate > 0 ? Math.ceil(gddRemainingInStage / dailyRate) : 0;

  // Determine stage health index based on thermal pace vs calendar pace
  const expectedDapForGdd = (accumulatedGdd / profile.targetMaturityGdd) * profile.durationDays;
  let stageHealthIndex: 'Ahead of Schedule' | 'On Track' | 'Delayed (Temp Stress)' = 'On Track';
  let stageHealthColor = '#06b6d4'; // Cyan

  if (dap < expectedDapForGdd - 3) {
    stageHealthIndex = 'Ahead of Schedule';
    stageHealthColor = '#10b981'; // Emerald
  } else if (dap > expectedDapForGdd + 4 || currentTemp < profile.tBase + 3) {
    stageHealthIndex = 'Delayed (Temp Stress)';
    stageHealthColor = '#f59e0b'; // Amber
  }

  const stagesList = stageRanges.map((st, idx) => ({
    ...st,
    isCurrent: idx === stageIndex,
    isCompleted: idx < stageIndex,
    isUpcoming: idx > stageIndex,
  }));

  return {
    currentStage,
    stageIndex,
    stageCompletionPct,
    totalMaturityPct,
    accumulatedGdd,
    targetMaturityGdd: profile.targetMaturityGdd,
    dap,
    totalDurationDays: profile.durationDays,
    daysToNextStage,
    dailyGddRate: +(dailyRate).toFixed(1),
    stageHealthIndex,
    stageHealthColor,
    stagesList,
  };
}
