import { ref, set, push, get, onValue } from './firebase';
import { db } from './firebase';

const PLOTS = ['plot_1', 'plot_2', 'plot_3', 'plot_4'];

const baseReadingsMap: Record<string, any> = {
  plot_1: { airTemp: 24, soilTemp: 22, humidity: 60, soilMoisture: 48, light: 50000, soilPh: 6.5, soilEc: 1.2, nitrogen: 45, phosphorus: 30, potassium: 50 },
  plot_2: { airTemp: 22, soilTemp: 20, humidity: 65, soilMoisture: 52, light: 45000, soilPh: 6.2, soilEc: 1.4, nitrogen: 50, phosphorus: 28, potassium: 48 },
  plot_3: { airTemp: 26, soilTemp: 24, humidity: 55, soilMoisture: 42, light: 55000, soilPh: 6.8, soilEc: 1.1, nitrogen: 40, phosphorus: 32, potassium: 55 },
  plot_4: { airTemp: 23, soilTemp: 21, humidity: 58, soilMoisture: 50, light: 48000, soilPh: 6.4, soilEc: 1.3, nitrogen: 42, phosphorus: 30, potassium: 52 }
};

let demoModeEnabled = true;
let currentDevicesMap: Record<string, any> = {};
let lastAlerts: any = {};

export const seedDatabase = async () => {
  // Seed Settings
  await set(ref(db, 'settings'), {
    demoMode: true
  });

  onValue(ref(db, 'settings/demoMode'), (snap) => {
    demoModeEnabled = snap.val();
  });

  // Seed System Status for Edge Resilience
  await set(ref(db, 'system_status'), {
    edge_online: true,
    last_cloud_sync: Date.now(),
    offline_buffer_count: 0
  });

  // Seed Real Inherited Properties from Sarpan Seeds variety specifications (Dharwad)
  const dataNotice = "Sarpan Hybrid Seeds Co. Pvt. Ltd., NH-4 Bypass, Belgaum Road, Dharwad — product specifications, retrieved August 2026. T_base/T_upper/LAI_max are literature-derived crop-physiology constants, not variety-specific — treat as starting priors to refine with on-site GDD-vs-phenology data.";

  const inheritedPropsMap: Record<string, any> = {
    plot_1: {
      _data_source: dataNotice,
      botanical_name: "Solanum lycopersicum",
      seed_type: "F1 hybrid",
      t_base_c: { min: 7, max: 10, practical: 10 },
      t_upper_c: { min: 28, max: 33 },
      optimal_germination_temp_c: { min: 20, max: 27 },
      germination_days: { min: 5, max: 10 },
      lai_max: { min: 3.5, max: 4.5 },
      plant_type: "Semi-indeterminate",
      plant_height_maturity_cm: { note: "not published for STH-520; semi-indeterminate typically 90-150cm unstaked" },
      fruit_type: "Flat-ridged, thick skin, green shoulder, acidic",
      fruit_size: "70-90g per fruit, clusters of 5-7",
      days_to_first_harvest: { note: "not published; typically ~60-70 DAT for semi-indeterminate hybrids" },
      total_duration_days: { note: "all-season, 90-120+ days productive window" },
      spacing_row_ft: { min: 3 },
      spacing_plant_ft: { min: 1.5, max: 2 },
      bred_disease_tolerance: null,
      bred_pest_tolerance: null,
      yield_potential_rating: "High-yielding (qualitative)",
      source: "sarpanseeds.com/collections/tomato/products/sarpan-f1-sth-520"
    },
    plot_2: {
      _data_source: dataNotice,
      botanical_name: "Capsicum annuum",
      seed_type: "F1 hybrid",
      t_base_c: { practical: 10 },
      t_upper_c: { min: 28, max: 35 },
      optimal_germination_temp_c: { min: 22, max: 28 },
      germination_days: { min: 8, max: 14 },
      lai_max: { min: 3.0, max: 4.0 },
      plant_type: "Upright (Dabbi Byadgi type)",
      plant_height_maturity_cm: { min: 100, max: 120 },
      fruit_type: "Broad-shoulder, cherry-red at maturity, 410-430 ASTA colour",
      fruit_size: "15-18cm long",
      pungency_shu: { min: 5000, max: 6000 },
      days_to_first_harvest: { min: 60, max: 70 },
      total_duration_days: { min: 180, max: 210 },
      spacing_row_ft: { min: 2.7, max: 3 },
      spacing_plant_ft: { min: 1, max: 1.2 },
      bred_disease_tolerance: null,
      bred_pest_tolerance: null,
      yield_potential_rating: null,
      source: "sarpanseeds.com/collections/chilli-1/products/sarpan-f1-92-super"
    },
    plot_3: {
      _data_source: dataNotice,
      botanical_name: "Solanum melongena",
      seed_type: "F1 hybrid (Kudachi-type)",
      t_base_c: { min: 10, max: 11 },
      t_upper_c: { practical: 35 },
      optimal_germination_temp_c: { min: 22, max: 30 },
      germination_days: { min: 6, max: 10 },
      lai_max: { min: 5.0, max: 7.5 },
      plant_type: "Upright, good branching",
      plant_height_maturity_cm: { note: "not specified for 501; general Sarpan brinjal line 120-130cm" },
      fruit_type: "Oval, green with light-green/white stripes",
      fruit_size: "70-80g per fruit",
      days_to_first_harvest: { min: 48, max: 52, unit: "DAT" },
      total_duration_days: { min: 150, max: 160, unit: "DAT" },
      spacing_row_ft: { min: 2.5, max: 3 },
      spacing_plant_ft: { practical: 2 },
      bred_disease_tolerance: "Good tolerance to little leaf (phytoplasma); good general foliage disease tolerance",
      bred_pest_tolerance: null,
      yield_potential_rating: "Excellent (qualitative)",
      source: "sarpanseeds.com/collections/brinjal/products/sarpan-kudachi-501"
    },
    plot_4: {
      _data_source: dataNotice,
      botanical_name: "Abelmoschus esculentus",
      seed_type: "F1 hybrid",
      t_base_c: { min: 12, max: 15.5, note: "not well-established; one study used 5C; treat as calibration variable" },
      t_upper_c: { practical: 35, note: "provisional, aligned to pepper/eggplant ceiling pending field calibration" },
      optimal_germination_temp_c: { min: 25, max: 35, note: "germination drops sharply below ~20C" },
      germination_days: { min: 4, max: 8 },
      lai_max: { min: 3.0, max: 4.4 },
      plant_type: "Erect, tall, single dominant stem",
      plant_height_maturity_cm: { min: 160, max: 170 },
      fruit_type: "Dark green, glossy pods",
      fruit_size: "8-9cm pod length (tender-harvest stage)",
      days_to_first_harvest: { min: 50, max: 52, unit: "DAS" },
      total_duration_days: { min: 115, max: 125, unit: "DAS" },
      spacing_row_ft: { min: 1.5, max: 2 },
      spacing_plant_ft: { practical: 1 },
      bred_disease_tolerance: "Highly tolerant to Yellow Vein Mosaic Virus (YVMV) and Enation Leaf Curl Virus (ELCV)",
      bred_pest_tolerance: null,
      yield_potential_rating: "Very good (qualitative)",
      source: "sarpanseeds.com/collections/okra-beans-and-clusterbean/products/sarpan-airavat-bhendi-seeds"
    }
  };

  for (const pid of PLOTS) {
    await set(ref(db, `inherited_properties/${pid}`), inheritedPropsMap[pid]);
  }

  // Seed Farm Meta
  await set(ref(db, 'farm_meta'), {
    name: 'College Test Farm',
    location: 'Campus Greenhouse A',
    totalPlots: 4
  });

  // Seed Plots with IIIT Dharwad campus anchor coordinates & inherited_properties
  const plotMetaList = [
    { id: 'plot_1', name: 'Plot 1 (Tomato — Sarpan F1-STH-520)', crop: 'Tomato (Sarpan F1-STH-520)', section: 'North Wing', status: 'Active', healthStatus: 'Excellent', plantedDate: '2023-10-01', location: { lat: 15.4592, lng: 75.0075 }, inherited_properties: inheritedPropsMap.plot_1 },
    { id: 'plot_2', name: 'Plot 2 (Lettuce — Butterhead Green)', crop: 'Lettuce (Butterhead Green)', section: 'East Wing', status: 'Active', healthStatus: 'Needs Attention', plantedDate: '2023-10-15', location: { lat: 15.4586, lng: 75.0082 }, inherited_properties: inheritedPropsMap.plot_2 },
    { id: 'plot_3', name: 'Plot 3 (Pepper — Bell Pepper Red)', crop: 'Pepper (Bell Pepper Red)', section: 'South Wing', status: 'Active', healthStatus: 'Good', plantedDate: '2023-09-20', location: { lat: 15.4595, lng: 75.0081 }, inherited_properties: inheritedPropsMap.plot_3 },
    { id: 'plot_4', name: 'Plot 4 (Strawberry — Chandler Sweet)', crop: 'Strawberry (Chandler Sweet)', section: 'West Wing', status: 'Active', healthStatus: 'Good', plantedDate: '2023-11-01', location: { lat: 15.4583, lng: 75.0072 }, inherited_properties: inheritedPropsMap.plot_4 }
  ];

  for (const p of plotMetaList) {
    await set(ref(db, `plots/${p.id}`), p);
  }

  // Seed Devices for all plots
  for (const pid of PLOTS) {
    await set(ref(db, `devices/${pid}`), {
      irrigation: { enabled: false, mode: 'auto' },
      hvac: { enabled: true, mode: 'auto' },
      growLight: { enabled: false, mode: 'manual' }
    });

    onValue(ref(db, `devices/${pid}`), (snap) => {
      currentDevicesMap[pid] = snap.val() || {};
    });
  }

  // Seed Sensors definition
  await set(ref(db, `sensors`), {
    'SENS_TEMP_1': { id: 'SENS_TEMP_1', type: 'Air Temp & Humidity', location: 'Plot 1 - Canopy', battery: '85%', status: 'Active' },
    'SENS_SOIL_1': { id: 'SENS_SOIL_1', type: 'Soil Moisture & Temp', location: 'Plot 1 - Root Zone', battery: '92%', status: 'Active' },
    'SENS_LIGHT_1': { id: 'SENS_LIGHT_1', type: 'PAR Light Sensor', location: 'Plot 1 - Top', battery: '100%', status: 'Active' },
    'SENS_NPK_1': { id: 'SENS_NPK_1', type: 'Soil NPK & pH', location: 'Plot 1 - Substrate', battery: '60%', status: 'Active' }
  });

  // Seed Camera
  await set(ref(db, 'camera'), {
    status: 'Online',
    url: 'demo'
  });

  // Seed Crop Vision Base for all plots
  const cropVisionBaseMap: Record<string, any> = {
    plot_1: { plantHeight: 45, canopyCoverage: 60, growthStage: 'Vegetative', fruitRipeness: 25, yieldEstimate: 4.5, diseaseRisk: 5, lastAnalyzed: Date.now() },
    plot_2: { plantHeight: 22, canopyCoverage: 75, growthStage: 'Vegetative', fruitRipeness: 10, yieldEstimate: 3.2, diseaseRisk: 2, lastAnalyzed: Date.now() },
    plot_3: { plantHeight: 38, canopyCoverage: 50, growthStage: 'Flowering', fruitRipeness: 40, yieldEstimate: 4.1, diseaseRisk: 8, lastAnalyzed: Date.now() },
    plot_4: { plantHeight: 18, canopyCoverage: 65, growthStage: 'Fruiting', fruitRipeness: 60, yieldEstimate: 3.8, diseaseRisk: 4, lastAnalyzed: Date.now() }
  };

  for (const pid of PLOTS) {
    await set(ref(db, `crop_vision/${pid}`), cropVisionBaseMap[pid]);
  }
};

const triggerAlert = async (type: string, message: string, priority: string) => {
  if (lastAlerts[type] && Date.now() - lastAlerts[type] < 60000) return;
  lastAlerts[type] = Date.now();
  await push(ref(db, 'alerts'), {
    id: Math.random().toString(36).substring(7),
    type,
    message,
    priority,
    timestamp: Date.now(),
    read: false
  });
};

const processAutomationAndAI = async (plotId: string, readings: any) => {
  const airTemp = readings.environmental?.airTemp ?? readings.airTemp;
  const soilMoisture = readings.soil?.soilMoisture ?? readings.soilMoisture;
  const light = readings.environmental?.light ?? readings.light;

  const currentDevices = currentDevicesMap[plotId] || {};
  const newDevices = { ...currentDevices };
  let deviceChanged = false;

  if (newDevices.irrigation?.mode === 'auto') {
    if (soilMoisture < 45 && !newDevices.irrigation.enabled) {
      newDevices.irrigation.enabled = true;
      deviceChanged = true;
      triggerAlert('Low Soil Moisture', `Soil moisture in ${plotId} dropped below 45%. Irrigation turned ON.`, 'high');
    } else if (soilMoisture >= 60 && newDevices.irrigation.enabled) {
      newDevices.irrigation.enabled = false;
      deviceChanged = true;
    }
  }

  if (newDevices.hvac?.mode === 'auto') {
    if (airTemp > 30 && !newDevices.hvac.enabled) {
      newDevices.hvac.enabled = true;
      deviceChanged = true;
      triggerAlert('High Temperature', `Air temperature in ${plotId} exceeded 30°C. HVAC turned ON.`, 'medium');
    } else if (airTemp <= 26 && newDevices.hvac.enabled) {
      newDevices.hvac.enabled = false;
      deviceChanged = true;
    }
  }

  if (newDevices.growLight?.mode === 'auto') {
    if (light < 40000 && !newDevices.growLight.enabled) {
      newDevices.growLight.enabled = true;
      deviceChanged = true;
      triggerAlert('Low Light', `Light level in ${plotId} dropped. Grow lights turned ON.`, 'low');
    } else if (light >= 55000 && newDevices.growLight.enabled) {
      newDevices.growLight.enabled = false;
      deviceChanged = true;
    }
  }

  if (deviceChanged) {
    await set(ref(db, `devices/${plotId}`), newDevices);
  }

  // Generate AI Recommendations per plot
  const recommendations = [];
  if (soilMoisture < 45) {
    recommendations.push({ reason: 'Low soil moisture detected.', impact: 'Water stress may reduce crop growth.', solution: 'Turn on irrigation for 15 minutes.' });
  }
  if (airTemp > 30) {
    recommendations.push({ reason: 'Temperature above optimal range.', impact: 'Possible heat stress.', solution: 'Increase ventilation.' });
  }
  if (light < 40000) {
    recommendations.push({ reason: 'Light intensity below optimal range.', impact: 'Reduced photosynthesis.', solution: 'Turn on grow lights.' });
  }
  if (recommendations.length === 0) {
    recommendations.push({ reason: 'Crop conditions are within the optimal range.', impact: 'Healthy growth expected.', solution: 'No immediate intervention required.' });
  }

  await set(ref(db, `aiRecommendations/${plotId}`), {
    recommendations,
    healthScore: soilMoisture < 45 ? 75 : airTemp > 30 ? 80 : 95,
    yieldPotential: soilMoisture < 45 ? 70 : airTemp > 30 ? 78 : 90
  });
};

export const startSimulator = () => {
  const simSoilMoistureMap: Record<string, number> = {
    plot_1: baseReadingsMap.plot_1.soilMoisture,
    plot_2: baseReadingsMap.plot_2.soilMoisture,
    plot_3: baseReadingsMap.plot_3.soilMoisture,
    plot_4: baseReadingsMap.plot_4.soilMoisture
  };
  
  setInterval(async () => {
    if (!demoModeEnabled) return;

    for (const plotId of PLOTS) {
      const baseReadings = baseReadingsMap[plotId];
      const currentDevices = currentDevicesMap[plotId] || {};

      if (currentDevices.irrigation?.enabled) {
        simSoilMoistureMap[plotId] = Math.min(simSoilMoistureMap[plotId] + 2, 70);
      } else {
        simSoilMoistureMap[plotId] = Math.max(simSoilMoistureMap[plotId] - 0.5, 30);
      }

      const airTemp = +(baseReadings.airTemp + (currentDevices.hvac?.enabled ? -2 : 0) + (Math.random() * 4 - 1)).toFixed(1);
      const humidity = +(baseReadings.humidity + (Math.random() * 10 - 5)).toFixed(1);
      const light = +(baseReadings.light + (currentDevices.growLight?.enabled ? 20000 : 0) + (Math.random() * 2000 - 1000)).toFixed(0);
      const soilMoisture = +simSoilMoistureMap[plotId].toFixed(1);

      // Calculate derived environmental params
      const vpd = +((1 - humidity / 100) * 0.61078 * Math.exp((17.27 * airTemp) / (airTemp + 237.3))).toFixed(2);
      const par = +(light * 0.0185).toFixed(1);
      const dli = +((par * 12 * 3600) / 1000000).toFixed(2);
      const dewPoint = +(airTemp - ((100 - humidity) / 5)).toFixed(1);

      // Construct v2 Bucketed Payload
      const bucketedReadings = {
        timestamp: Date.now(),
        environmental: {
          airTemp,
          humidity,
          light,
          vpd,
          par,
          dli,
          sunlight: 8.5,
          solar_irradiance_wm2: +(550 + Math.random() * 100 - 50).toFixed(0),
          sunshine_hours: +(7.5 + Math.random() * 0.4 - 0.2).toFixed(1),
          self_shading_pct: plotId === 'plot_3' ? 58 : plotId === 'plot_1' ? 45 : 35,
          orientation_shading_note: "No significant shading — N-S bed orientation",
          wind_speed_ms: +(3.2 + Math.random() * 1.0 - 0.5).toFixed(1),
          wind_direction_deg: +(210 + Math.random() * 20 - 10).toFixed(0),
          gust_peak_ms: +(11.5 + Math.random() * 2.0).toFixed(1),
          gust_events_per_day: 4,
          dew_point_c: dewPoint,
          leaf_wetness_hours: +(2.5 + Math.random() * 0.8).toFixed(1),
          rainfall_mm: 0.0,
          barometric_pressure_hpa: +(1013.2 + Math.random() * 2 - 1).toFixed(1),
          co2_ppm: +(420 + Math.random() * 12 - 6).toFixed(0),
          windSpeed: +(3.2 + Math.random() * 1.0 - 0.5).toFixed(1),
          dewPoint,
          leafWetness: +(2.5 + Math.random() * 0.8).toFixed(1)
        },
        soil: {
          soilTemp: +(baseReadings.soilTemp + (Math.random() * 2 - 1)).toFixed(1),
          soilMoisture,
          soilPh: +(baseReadings.soilPh + (Math.random() * 0.4 - 0.2)).toFixed(1),
          soilEc: +(baseReadings.soilEc + (Math.random() * 0.2 - 0.1)).toFixed(2),
          nitrogen: +(baseReadings.nitrogen + (Math.random() * 4 - 2)).toFixed(1),
          phosphorus: +(baseReadings.phosphorus + (Math.random() * 4 - 2)).toFixed(1),
          potassium: +(baseReadings.potassium + (Math.random() * 4 - 2)).toFixed(1)
        },
        terrain: {
          elevation: 120,
          slope: 2.5
        },
        water_quality: {
          waterPh: +(6.8 + Math.random() * 0.2 - 0.1).toFixed(1),
          waterEc: +(1.2 + Math.random() * 0.1).toFixed(2),
          turbidity: +(1.8 + Math.random() * 0.3).toFixed(1)
        },
        // Backward compatible flat fields
        airTemp,
        soilTemp: +(baseReadings.soilTemp + (Math.random() * 2 - 1)).toFixed(1),
        humidity,
        soilMoisture,
        light,
        soilPh: +(baseReadings.soilPh + (Math.random() * 0.4 - 0.2)).toFixed(1),
        soilEc: +(baseReadings.soilEc + (Math.random() * 0.2 - 0.1)).toFixed(2),
        nitrogen: +(baseReadings.nitrogen + (Math.random() * 4 - 2)).toFixed(1),
        phosphorus: +(baseReadings.phosphorus + (Math.random() * 4 - 2)).toFixed(1),
        potassium: +(baseReadings.potassium + (Math.random() * 4 - 2)).toFixed(1),
        vpd,
        par,
        dli,
        sunlight: 8.5,
        windSpeed: +(12 + Math.random() * 4 - 2).toFixed(1),
        dewPoint,
        leafWetness: +(15 + Math.random() * 10).toFixed(1),
        elevation: 120,
        slope: 2.5,
        waterPh: 7.0,
        waterEc: 1.1,
        turbidity: 2.3
      };

      // Write to v2 paths: live_readings & sensorReadings
      await set(ref(db, `live_readings/${plotId}`), bucketedReadings);
      await set(ref(db, `sensorReadings/${plotId}`), bucketedReadings);
      await push(ref(db, `historicalData/${plotId}`), bucketedReadings);

      processAutomationAndAI(plotId, bucketedReadings);
    }

    // Update system_status cloud sync
    const statusSnap = await get(ref(db, 'system_status'));
    const currStatus = statusSnap.val() || { edge_online: true, offline_buffer_count: 0 };
    await set(ref(db, 'system_status'), {
      ...currStatus,
      last_cloud_sync: Date.now()
    });
  }, 3000);
};

export const analyzeCropSimulated = async (targetPlotId: string = 'plot_1') => {
  await set(ref(db, `crop_vision/${targetPlotId}/lastAnalyzed`), Date.now());
  const r = Math.random();
  await set(ref(db, `crop_vision/${targetPlotId}/diseaseRisk`), +(r > 0.8 ? 15 : 2 + r * 3).toFixed(1));
  await set(ref(db, `crop_vision/${targetPlotId}/yieldEstimate`), +(4.2 + r * 1.5).toFixed(1));
  await triggerAlert('Analysis Complete', `Crop Vision analysis updated for ${targetPlotId}.`, 'low');
};


