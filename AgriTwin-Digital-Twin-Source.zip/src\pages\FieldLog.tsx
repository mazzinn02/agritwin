import React, { useState, useEffect, useMemo } from 'react';
import { ref, get, query, orderByChild, startAt, endAt } from '../lib/firebase';
import { db } from '../lib/firebase';
import { Database, Download, Calendar, Search, Check, Table as TableIcon, Activity, Flame } from 'lucide-react';

const OPTIMAL_RANGES: Record<string, [number, number]> = {
  airTemp: [20, 30],
  soilMoisture: [15, 25],
  humidity: [50, 70],
  light: [400, 800],
  soilPh: [6, 6.8],
  soilEc: [1.0, 2.5],
  nitrogen: [30, 60],
  phosphorus: [15, 30],
  potassium: [100, 200],
  vpd: [0.8, 1.2],
  par: [400, 1000],
  dli: [15, 30],
  sunlight: [6, 12],
  windSpeed: [5, 20],
  dewPoint: [10, 20],
  leafWetness: [0, 20],
  elevation: [50, 500],
  slope: [0, 5],
  waterPh: [6.5, 7.5],
  waterEc: [0.8, 1.5],
  turbidity: [0, 5]
};

const PLOTS = [
  { id: 'plot_1', name: 'Plot 1 (Tomato)' },
  { id: 'plot_2', name: 'Plot 2 (Lettuce)' },
  { id: 'plot_3', name: 'Plot 3 (Pepper)' },
  { id: 'plot_4', name: 'Plot 4 (Strawberry)' }
];

const MultiSelectDropdown = ({ options, selected, onChange }: any) => {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');

  const filtered = options.filter((o: any) => o.name.toLowerCase().includes(search.toLowerCase()));

  const toggle = (id: string) => {
    if (selected.includes(id)) {
      onChange(selected.filter((s: string) => s !== id));
    } else {
      onChange([...selected, id]);
    }
  };

  return (
    <div className="relative">
      <div 
        onClick={() => setOpen(!open)}
        className="w-full border border-slate-200 rounded-xl p-2.5 bg-white cursor-pointer min-h-[42px] flex items-center justify-between text-xs font-bold text-slate-700 shadow-xs hover:border-slate-300"
      >
        <span>
          {selected.length === 0 ? 'Select plots...' : `${selected.length} plots selected`}
        </span>
      </div>
      {open && (
        <div className="absolute z-20 w-64 mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl p-1.5">
          <div className="p-2 border-b border-slate-100 flex items-center">
            <Search className="w-4 h-4 text-slate-400 mr-2" />
            <input 
              type="text" 
              placeholder="Search plots..." 
              className="w-full text-xs font-medium outline-none text-slate-800"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <div className="max-h-48 overflow-y-auto p-1 space-y-1">
            {filtered.map((o: any) => (
              <div 
                key={o.id} 
                onClick={() => toggle(o.id)}
                className="flex items-center px-2.5 py-1.5 hover:bg-slate-50 rounded-xl cursor-pointer text-xs font-medium text-slate-700"
              >
                <div className={`w-4 h-4 rounded-md border mr-2 flex items-center justify-center ${selected.includes(o.id) ? 'bg-sky-600 border-sky-600' : 'border-slate-300'}`}>
                  {selected.includes(o.id) && <Check className="w-3 h-3 text-white" />}
                </div>
                {o.name}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export const FieldLog = () => {
  const [historyData, setHistoryData] = useState<any[]>([]);
  const [activeView, setActiveView] = useState<'Table' | 'Timeline' | 'Heatmap'>('Table');
  const [selectedPlots, setSelectedPlots] = useState<string[]>(['plot_1']);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [heatmapParam, setHeatmapParam] = useState('airTemp');

  const fetchData = async () => {
    if (selectedPlots.length === 0) {
      setHistoryData([]);
      return;
    }
    
    let allData: any[] = [];

    const startTs = startDate ? new Date(startDate).getTime() : 0;
    const endTs = endDate ? new Date(endDate).getTime() : Number.MAX_SAFE_INTEGER;

    for (const plot of selectedPlots) {
      const constraints: any[] = [orderByChild('timestamp')];
      if (startTs) constraints.push(startAt(startTs));
      if (endTs !== Number.MAX_SAFE_INTEGER) constraints.push(endAt(endTs));

      const historyQuery = query(ref(db, `historicalData/${plot}`), ...constraints);
      const snapshot = await get(historyQuery);
      
      if (snapshot.exists()) {
        const data = snapshot.val();
        Object.entries(data).forEach(([id, val]: any) => {
          allData.push({
            id: `${plot}_${id}`,
            plotId: plot,
            ...val,
            timeStr: new Date(val.timestamp).toLocaleString(),
            dateOnly: new Date(val.timestamp).toLocaleDateString()
          });
        });
      }
    }

    allData.sort((a, b) => b.timestamp - a.timestamp);
    setHistoryData(allData);
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, [selectedPlots, startDate, endDate]);

  const escapeCSVField = (field: any) => {
    if (field === null || field === undefined) return '""';
    const str = String(field);
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const handleExport = () => {
    const headers = ["Plot", "Time", "Air Temp", "Humidity", "Soil Moisture", "Light", "pH", "EC", "Nitrogen", "Phosphorus", "Potassium"];
    const rows = historyData.map(row => [
      row.plotId,
      row.timeStr,
      row.airTemp,
      row.humidity,
      row.soilMoisture,
      row.light,
      row.soilPh,
      row.soilEc,
      row.nitrogen,
      row.phosphorus,
      row.potassium
    ].map(escapeCSVField).join(","));

    const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `field_log_export.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const timelineEvents = useMemo(() => {
    const events: any[] = [];
    historyData.forEach(row => {
      Object.entries(OPTIMAL_RANGES).forEach(([param, range]) => {
        const val = row[param];
        if (val !== undefined) {
          const margin = (range[1] - range[0]) * 0.2;
          if (val < range[0] - margin || val > range[1] + margin) {
            events.push({ ...row, param, val, severity: 'critical' });
          } else if (val < range[0] || val > range[1]) {
            events.push({ ...row, param, val, severity: 'warning' });
          }
        }
      });
    });
    return events;
  }, [historyData]);

  const heatmapData = useMemo(() => {
    const days: Record<string, number[]> = {};
    historyData.forEach(row => {
      if (!days[row.dateOnly]) days[row.dateOnly] = [];
      if (row[heatmapParam] !== undefined) {
        days[row.dateOnly].push(row[heatmapParam]);
      }
    });

    return Object.entries(days).map(([date, vals]) => {
      const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
      return { date, avg: parseFloat(avg.toFixed(1)) };
    }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [historyData, heatmapParam]);

  return (
    <div className="space-y-6 text-slate-800">
      {/* Top Header & Export Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 flex items-center">
            <Database className="mr-3 text-sky-600 w-8 h-8" />
            Field Log & Telemetry History
          </h2>
          <p className="text-slate-500 text-sm mt-1 font-medium">Historical sensor telemetry records, audit logs, and anomaly detection</p>
        </div>

        <button 
          onClick={handleExport}
          className="flex items-center space-x-2 px-4 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition-all cursor-pointer self-start sm:self-auto active:scale-95"
        >
          <Download className="w-4 h-4" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filter Control Bar */}
      <div className="bg-white/95 backdrop-blur-sm p-6 rounded-3xl shadow-sm border border-slate-200/80 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="w-56">
              <MultiSelectDropdown 
                options={PLOTS} 
                selected={selectedPlots} 
                onChange={setSelectedPlots} 
              />
            </div>

            <div className="flex items-center space-x-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2">
              <Calendar className="w-4 h-4 text-slate-400" />
              <input 
                type="date" 
                value={startDate} 
                onChange={e => setStartDate(e.target.value)} 
                className="text-xs bg-transparent outline-none text-slate-700 font-semibold"
              />
              <span className="text-slate-400 text-xs font-bold">to</span>
              <input 
                type="date" 
                value={endDate} 
                onChange={e => setEndDate(e.target.value)} 
                className="text-xs bg-transparent outline-none text-slate-700 font-semibold"
              />
            </div>
          </div>

          {/* View Mode Toggle */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setActiveView('Table')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'Table' ? 'bg-white text-sky-700 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>Table</span>
            </button>
            <button
              onClick={() => setActiveView('Timeline')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'Timeline' ? 'bg-white text-sky-700 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>Timeline</span>
            </button>
            <button
              onClick={() => setActiveView('Heatmap')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeView === 'Heatmap' ? 'bg-white text-sky-700 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Heatmap</span>
            </button>
          </div>
        </div>

        {/* View Mode Content */}
        {activeView === 'Table' && (
          <div className="overflow-x-auto border border-slate-200 rounded-2xl">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 font-bold uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="p-3.5">Plot</th>
                  <th className="p-3.5">Timestamp</th>
                  <th className="p-3.5">Air Temp</th>
                  <th className="p-3.5">Humidity</th>
                  <th className="p-3.5">Soil Moisture</th>
                  <th className="p-3.5">Light</th>
                  <th className="p-3.5">Soil pH</th>
                  <th className="p-3.5">Nitrogen</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-medium">
                {historyData.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-8 text-center text-slate-400 font-medium">No historical records found for selected filters.</td>
                  </tr>
                ) : (
                  historyData.slice(0, 50).map((row) => (
                    <tr key={row.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-3.5 font-bold text-slate-900">{row.plotId}</td>
                      <td className="p-3.5">{row.timeStr}</td>
                      <td className="p-3.5 font-mono">{row.airTemp ?? row.environmental?.airTemp ?? '--'} °C</td>
                      <td className="p-3.5 font-mono">{row.humidity ?? row.environmental?.humidity ?? '--'} %</td>
                      <td className="p-3.5 font-mono">{row.soilMoisture ?? row.soil?.soilMoisture ?? '--'} %</td>
                      <td className="p-3.5 font-mono">{row.light ?? row.environmental?.light ?? '--'} lx</td>
                      <td className="p-3.5 font-mono">{row.soilPh ?? row.soil?.soilPh ?? '--'}</td>
                      <td className="p-3.5 font-mono">{row.nitrogen ?? row.soil?.nitrogen ?? '--'} mg/kg</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        )}

        {activeView === 'Timeline' && (
          <div className="space-y-3 pt-2">
            {timelineEvents.length === 0 ? (
              <p className="p-8 text-center text-slate-400 font-medium">No anomaly events found.</p>
            ) : (
              timelineEvents.slice(0, 20).map((ev, i) => (
                <div key={i} className={`p-4 rounded-2xl border text-xs flex items-center justify-between ${
                  ev.severity === 'critical' ? 'bg-rose-50 border-rose-200 text-rose-800' : 'bg-amber-50 border-amber-200 text-amber-800'
                }`}>
                  <div className="flex items-center space-x-3">
                    <span className={`w-2.5 h-2.5 rounded-full ${ev.severity === 'critical' ? 'bg-rose-600' : 'bg-amber-600'}`} />
                    <span className="font-bold">{ev.plotId}: {ev.param} reached {ev.val}</span>
                  </div>
                  <span className="font-mono text-slate-500">{ev.timeStr}</span>
                </div>
              ))
            )}
          </div>
        )}

        {activeView === 'Heatmap' && (
          <div className="space-y-4 pt-2">
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold text-slate-500 uppercase">Parameter:</span>
              <select 
                value={heatmapParam} 
                onChange={e => setHeatmapParam(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-800"
              >
                <option value="airTemp">Air Temperature</option>
                <option value="soilMoisture">Soil Moisture</option>
                <option value="humidity">Humidity</option>
                <option value="nitrogen">Nitrogen</option>
              </select>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {heatmapData.map((day, idx) => (
                <div key={idx} className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-center space-y-1">
                  <div className="text-[11px] text-slate-500 font-bold">{day.date}</div>
                  <div className="text-xl font-black text-slate-900">{day.avg}</div>
                  <div className="text-[10px] text-sky-700 font-bold uppercase">{heatmapParam}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default FieldLog;
