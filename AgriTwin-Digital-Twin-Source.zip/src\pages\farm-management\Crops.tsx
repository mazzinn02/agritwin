import React, { useState, useEffect } from 'react';
import { ref, onValue, set, push, remove } from '../../lib/firebase';
import { db } from '../../lib/firebase';
import { 
  Sprout, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  AlertTriangle, 
  Sparkles, 
  Check, 
  X, 
  Thermometer, 
  Droplets, 
  Calendar, 
  Scale, 
  Dna, 
  ShieldCheck, 
  Layers, 
  ExternalLink,
  BookOpen
} from 'lucide-react';
import { 
  CropData, 
  ensureCropsSeeded, 
  COMMON_CROP_PRESETS, 
  checkCropAssignedToPlot 
} from '../../lib/crop-management';

export const Crops: React.FC = () => {
  const [crops, setCrops] = useState<CropData[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  
  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingCrop, setEditingCrop] = useState<CropData | null>(null);
  const [cropToDelete, setCropToDelete] = useState<CropData | null>(null);
  const [deleteBlockedReason, setDeleteBlockedReason] = useState<string | null>(null);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Form State
  const initialFormState: Omit<CropData, 'id'> = {
    name: '',
    botanical_name: '',
    growth_duration_days: 90,
    expected_yield_per_sqm: 4.0,
    water_requirement_note: 'Standard regular drip cycles',
    ideal_conditions: {
      temp_min_c: 20,
      temp_max_c: 30,
      humidity_min_pct: 50,
      humidity_max_pct: 70
    },
    inherited_properties: {
      t_base_c: 10,
      t_upper_c: 32,
      lai_max_min: 3.0,
      lai_max_max: 4.5,
      spacing_row_ft: 2.5,
      spacing_plant_ft: 1.5,
      bred_disease_tolerance: 'General foliage disease resilience',
      bred_pest_tolerance: 'Standard pest resilience',
      source: 'Internal Agronomy Records'
    },
    is_custom: true,
    created_at: Date.now()
  };

  const [formData, setFormData] = useState<Omit<CropData, 'id'>>(initialFormState);

  // Initial Ingestion & Firebase Listener
  useEffect(() => {
    ensureCropsSeeded();

    const cropsRef = ref(db, 'crops');
    const unsub = onValue(cropsRef, (snapshot) => {
      if (snapshot.exists()) {
        const val = snapshot.val();
        const list: CropData[] = Object.entries(val).map(([id, item]: any) => ({
          id,
          ...item
        }));
        setCrops(list);
      } else {
        setCrops([]);
      }
      setLoading(false);
    });

    return () => unsub();
  }, []);

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3500);
  };

  // Preset Selection Handler
  const handleSelectPreset = (presetName: string) => {
    const preset = COMMON_CROP_PRESETS.find(p => p.name === presetName);
    if (!preset) return;

    setFormData({
      name: preset.name,
      botanical_name: preset.botanical_name,
      growth_duration_days: preset.growth_duration_days,
      expected_yield_per_sqm: preset.expected_yield_per_sqm,
      water_requirement_note: preset.water_requirement_note,
      ideal_conditions: {
        temp_min_c: preset.temp_min_c,
        temp_max_c: preset.temp_max_c,
        humidity_min_pct: preset.humidity_min_pct,
        humidity_max_pct: preset.humidity_max_pct
      },
      inherited_properties: {
        t_base_c: preset.t_base_c,
        t_upper_c: preset.t_upper_c,
        lai_max_min: preset.lai_max_min,
        lai_max_max: preset.lai_max_max,
        spacing_row_ft: preset.spacing_row_ft,
        spacing_plant_ft: preset.spacing_plant_ft,
        bred_disease_tolerance: preset.bred_disease_tolerance,
        bred_pest_tolerance: preset.bred_pest_tolerance,
        source: 'Agronomy Database Preset'
      },
      is_custom: true,
      created_at: Date.now()
    });
  };

  const handleOpenAddModal = () => {
    setFormData(initialFormState);
    setEditingCrop(null);
    setIsAddModalOpen(true);
  };

  const handleOpenEditModal = (crop: CropData) => {
    setEditingCrop(crop);
    setFormData({
      name: crop.name,
      botanical_name: crop.botanical_name,
      growth_duration_days: crop.growth_duration_days,
      expected_yield_per_sqm: crop.expected_yield_per_sqm,
      water_requirement_note: crop.water_requirement_note || '',
      ideal_conditions: { ...crop.ideal_conditions },
      inherited_properties: { ...crop.inherited_properties },
      is_custom: crop.is_custom ?? true,
      created_at: crop.created_at || Date.now()
    });
    setIsAddModalOpen(true);
  };

  const handleSaveCrop = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    if (editingCrop) {
      // Update existing crop
      await set(ref(db, `crops/${editingCrop.id}`), {
        ...formData,
        updated_at: Date.now()
      });
      showToast(`Crop "${formData.name}" updated successfully.`);
    } else {
      // Create new crop with unique id
      await push(ref(db, 'crops'), {
        ...formData,
        is_custom: true,
        created_at: Date.now()
      });
      showToast(`New crop "${formData.name}" added to catalog.`);
    }

    setIsAddModalOpen(false);
    setEditingCrop(null);
  };

  const handleDeleteRequest = async (crop: CropData) => {
    setDeleteBlockedReason(null);
    // Check if crop is assigned to any active plot
    const assignedPlotName = await checkCropAssignedToPlot(crop.id, crop.name);
    if (assignedPlotName) {
      setDeleteBlockedReason(`Cannot delete "${crop.name}": This variety is currently assigned to ${assignedPlotName}. Please reassign the plot before deleting.`);
    }
    setCropToDelete(crop);
  };

  const handleConfirmDelete = async () => {
    if (!cropToDelete || deleteBlockedReason) return;
    await remove(ref(db, `crops/${cropToDelete.id}`));
    showToast(`Crop "${cropToDelete.name}" removed from catalog.`);
    setCropToDelete(null);
  };

  const filteredCrops = crops.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.botanical_name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 text-slate-800 font-sans">
      
      {/* Toast Notification */}
      {successToast && (
        <div className="fixed top-6 right-6 z-50 p-4 bg-emerald-600 text-white font-bold rounded-2xl shadow-xl flex items-center space-x-2 animate-fadeIn">
          <Check className="w-5 h-5 text-emerald-200" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center">
              <Sprout className="mr-3 text-emerald-600 w-8 h-8" />
              Crop Catalog Management
            </h2>
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
              {crops.length} Varieties
            </span>
          </div>
          <p className="text-slate-500 text-sm mt-1 font-medium">
            Manage agronomic crop definitions, physiological constants, ideal micro-climates, and variety breeding specs
          </p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="flex items-center space-x-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm transition-all cursor-pointer active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Crop Variety</span>
        </button>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white/95 backdrop-blur-md p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center space-x-3">
        <Search className="w-4 h-4 text-slate-400" />
        <input 
          type="text"
          placeholder="Search crops by common name or botanical binomial (e.g. Tomato, Capsicum, Solanum)..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full text-xs font-semibold outline-none text-slate-800 placeholder-slate-400 bg-transparent"
        />
        {search && (
          <button onClick={() => setSearch('')} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Crop Cards Grid */}
      {loading ? (
        <div className="p-12 text-center text-slate-400 font-medium text-xs">
          Loading crop varieties...
        </div>
      ) : filteredCrops.length === 0 ? (
        <div className="bg-white/95 rounded-3xl p-12 text-center border border-slate-200/80 shadow-sm space-y-3">
          <Sprout className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="text-base font-black text-slate-700">No Crop Varieties Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            No crops matched your search filter. Add a new variety to start managing customized agronomic parameters.
          </p>
          <button
            onClick={handleOpenAddModal}
            className="px-4 py-2 bg-emerald-600 text-white font-bold rounded-xl text-xs"
          >
            Add New Variety
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
          {filteredCrops.map((crop) => (
            <div
              key={crop.id}
              className="bg-white/95 rounded-3xl p-6 border border-slate-200/80 shadow-sm hover:shadow-md hover:border-slate-300 transition-all flex flex-col justify-between space-y-4 relative group"
            >
              {/* Card Header */}
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <h3 className="text-lg font-black text-slate-900">{crop.name}</h3>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      crop.is_custom 
                        ? 'bg-purple-50 text-purple-700 border-purple-200' 
                        : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                    }`}>
                      {crop.is_custom ? 'Custom Variety' : 'Seed Catalog'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 font-medium italic">
                    {crop.botanical_name || 'Binomial not specified'}
                  </p>
                </div>

                {/* Edit & Delete Action Buttons */}
                <div className="flex items-center space-x-1">
                  <button
                    onClick={() => handleOpenEditModal(crop)}
                    title="Edit Crop Variety"
                    className="p-2 text-slate-400 hover:text-sky-700 hover:bg-sky-50 rounded-xl transition-colors cursor-pointer"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDeleteRequest(crop)}
                    title="Delete Crop Variety"
                    className="p-2 text-slate-400 hover:text-rose-700 hover:bg-rose-50 rounded-xl transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* 4-Up Core Metric Pills */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 text-center">
                  <div className="flex items-center justify-center space-x-1 text-[10px] text-slate-500 font-bold uppercase mb-0.5">
                    <Calendar className="w-3 h-3 text-sky-600" />
                    <span>Duration</span>
                  </div>
                  <div className="font-black text-slate-900 text-sm">{crop.growth_duration_days} days</div>
                </div>

                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 text-center">
                  <div className="flex items-center justify-center space-x-1 text-[10px] text-slate-500 font-bold uppercase mb-0.5">
                    <Scale className="w-3 h-3 text-emerald-600" />
                    <span>Yield / m²</span>
                  </div>
                  <div className="font-black text-slate-900 text-sm">{crop.expected_yield_per_sqm} kg</div>
                </div>

                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 text-center">
                  <div className="flex items-center justify-center space-x-1 text-[10px] text-slate-500 font-bold uppercase mb-0.5">
                    <Thermometer className="w-3 h-3 text-rose-500" />
                    <span>Ideal Temp</span>
                  </div>
                  <div className="font-black text-slate-900 text-sm">
                    {crop.ideal_conditions?.temp_min_c}&ndash;{crop.ideal_conditions?.temp_max_c}°C
                  </div>
                </div>

                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 text-center">
                  <div className="flex items-center justify-center space-x-1 text-[10px] text-slate-500 font-bold uppercase mb-0.5">
                    <Droplets className="w-3 h-3 text-sky-500" />
                    <span>Humidity</span>
                  </div>
                  <div className="font-black text-slate-900 text-sm">
                    {crop.ideal_conditions?.humidity_min_pct}&ndash;{crop.ideal_conditions?.humidity_max_pct}%
                  </div>
                </div>
              </div>

              {/* Water Requirement Note */}
              <div className="p-3 bg-sky-50/60 rounded-xl border border-sky-100 text-xs text-sky-950 flex items-start space-x-2">
                <Droplets className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold text-sky-900">Irrigation Profile: </strong>
                  <span>{crop.water_requirement_note || 'Standard balanced irrigation schedule.'}</span>
                </div>
              </div>

              {/* Inherited Biophysical Properties Breakdown */}
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 space-y-2 text-xs">
                <div className="flex items-center justify-between text-[11px] font-extrabold text-slate-600 uppercase tracking-wider">
                  <span className="flex items-center gap-1.5">
                    <Dna className="w-3.5 h-3.5 text-purple-600" />
                    Inherited Physiological Constants
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 font-bold">
                    T_base: {crop.inherited_properties?.t_base_c ?? 10}°C &bull; T_upper: {crop.inherited_properties?.t_upper_c ?? 33}°C
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600">
                  <div>
                    <span className="text-slate-400">LAI Max: </span>
                    <strong className="text-slate-800">{crop.inherited_properties?.lai_max_min} &ndash; {crop.inherited_properties?.lai_max_max}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400">Row × Plant Spacing: </span>
                    <strong className="text-slate-800">{crop.inherited_properties?.spacing_row_ft}ft × {crop.inherited_properties?.spacing_plant_ft}ft</strong>
                  </div>
                </div>

                {crop.inherited_properties?.bred_disease_tolerance && (
                  <div className="text-[11px] text-slate-600 pt-1 border-t border-slate-200/60">
                    <span className="text-emerald-700 font-bold">Bred Disease Tolerance: </span>
                    <span>{crop.inherited_properties.bred_disease_tolerance}</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ================= ADD / EDIT CROP MODAL ================= */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto relative shadow-2xl space-y-6 text-slate-800">
            
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <h3 className="text-xl font-black text-slate-900 flex items-center">
                  <Sprout className="w-6 h-6 mr-2 text-emerald-600" />
                  {editingCrop ? `Edit Crop: ${editingCrop.name}` : 'Add New Crop Variety'}
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-0.5">
                  Configure agronomic growth duration, yield potentials, and thermal constants
                </p>
              </div>

              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Example Presets Dropdown */}
            {!editingCrop && (
              <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-200 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    Pre-fill from Common Example Presets:
                  </span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {COMMON_CROP_PRESETS.map((preset) => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => handleSelectPreset(preset.name)}
                      className="px-3 py-1.5 bg-white hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold border border-emerald-300 transition-colors shadow-2xs cursor-pointer"
                    >
                      {preset.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSaveCrop} className="space-y-6">
              
              {/* Section 1: Basic Identity */}
              <div className="space-y-4">
                <h4 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider">
                  1. Crop Identity & Agronomic Targets
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Crop Variety Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Tomato (Sarpan F1-STH-520)"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Botanical Name (Binomial)</label>
                    <input
                      type="text"
                      placeholder="e.g. Solanum lycopersicum"
                      value={formData.botanical_name}
                      onChange={e => setFormData({ ...formData, botanical_name: e.target.value })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500 italic"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Growth Duration (Days) *</label>
                    <input
                      type="number"
                      required
                      min="1"
                      placeholder="e.g. 105"
                      value={formData.growth_duration_days}
                      onChange={e => setFormData({ ...formData, growth_duration_days: Number(e.target.value) })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Expected Yield (kg / m²) *</label>
                    <input
                      type="number"
                      step="0.1"
                      required
                      min="0.1"
                      placeholder="e.g. 4.8"
                      value={formData.expected_yield_per_sqm}
                      onChange={e => setFormData({ ...formData, expected_yield_per_sqm: Number(e.target.value) })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Water Requirement Note</label>
                  <input
                    type="text"
                    placeholder="e.g. High water demand during flowering; standard drip cycles"
                    value={formData.water_requirement_note}
                    onChange={e => setFormData({ ...formData, water_requirement_note: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Section 2: Ideal Conditions */}
              <div className="space-y-4 pt-4 border-t border-slate-200">
                <h4 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider">
                  2. Ideal Environmental Thresholds
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Min Temp (°C)</label>
                    <input
                      type="number"
                      value={formData.ideal_conditions.temp_min_c}
                      onChange={e => setFormData({
                        ...formData,
                        ideal_conditions: { ...formData.ideal_conditions, temp_min_c: Number(e.target.value) }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Max Temp (°C)</label>
                    <input
                      type="number"
                      value={formData.ideal_conditions.temp_max_c}
                      onChange={e => setFormData({
                        ...formData,
                        ideal_conditions: { ...formData.ideal_conditions, temp_max_c: Number(e.target.value) }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Min Humidity (%)</label>
                    <input
                      type="number"
                      value={formData.ideal_conditions.humidity_min_pct}
                      onChange={e => setFormData({
                        ...formData,
                        ideal_conditions: { ...formData.ideal_conditions, humidity_min_pct: Number(e.target.value) }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Max Humidity (%)</label>
                    <input
                      type="number"
                      value={formData.ideal_conditions.humidity_max_pct}
                      onChange={e => setFormData({
                        ...formData,
                        ideal_conditions: { ...formData.ideal_conditions, humidity_max_pct: Number(e.target.value) }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* Section 3: Inherited Properties */}
              <div className="space-y-4 pt-4 border-t border-slate-200">
                <h4 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider">
                  3. Inherited Biophysical & Breeding Properties
                </h4>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Base Temp (T_base °C)</label>
                    <input
                      type="number"
                      value={formData.inherited_properties.t_base_c}
                      onChange={e => setFormData({
                        ...formData,
                        inherited_properties: { ...formData.inherited_properties, t_base_c: Number(e.target.value) }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Upper Temp (T_upper °C)</label>
                    <input
                      type="number"
                      value={formData.inherited_properties.t_upper_c}
                      onChange={e => setFormData({
                        ...formData,
                        inherited_properties: { ...formData.inherited_properties, t_upper_c: Number(e.target.value) }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Row Spacing (ft)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={formData.inherited_properties.spacing_row_ft}
                      onChange={e => setFormData({
                        ...formData,
                        inherited_properties: { ...formData.inherited_properties, spacing_row_ft: Number(e.target.value) }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Plant Spacing (ft)</label>
                    <input
                      type="number"
                      step="0.1"
                      value={formData.inherited_properties.spacing_plant_ft}
                      onChange={e => setFormData({
                        ...formData,
                        inherited_properties: { ...formData.inherited_properties, spacing_plant_ft: Number(e.target.value) }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Bred Disease Tolerance</label>
                    <input
                      type="text"
                      placeholder="e.g. YVMV virus and powdery mildew tolerance"
                      value={formData.inherited_properties.bred_disease_tolerance}
                      onChange={e => setFormData({
                        ...formData,
                        inherited_properties: { ...formData.inherited_properties, bred_disease_tolerance: e.target.value }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-900 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">Data Source / Reference</label>
                    <input
                      type="text"
                      placeholder="e.g. sarpanseeds.com / Product Sheet"
                      value={formData.inherited_properties.source}
                      onChange={e => setFormData({
                        ...formData,
                        inherited_properties: { ...formData.inherited_properties, source: e.target.value }
                      })}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-semibold text-slate-900 outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm transition-all cursor-pointer active:scale-95"
                >
                  {editingCrop ? 'Save Changes' : 'Create Crop Variety'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= DELETE CONFIRMATION & SAFETY MODAL ================= */}
      {cropToDelete && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-4 text-slate-800">
            
            {deleteBlockedReason ? (
              /* Blocked Deletion Notice */
              <div className="space-y-4 text-center">
                <div className="w-14 h-14 bg-amber-50 rounded-2xl border border-amber-200 flex items-center justify-center mx-auto text-amber-600">
                  <AlertTriangle className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">Deletion Blocked</h3>
                  <p className="text-xs text-slate-600 mt-2 leading-relaxed font-medium">
                    {deleteBlockedReason}
                  </p>
                </div>
                <button
                  onClick={() => setCropToDelete(null)}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold"
                >
                  Understood
                </button>
              </div>
            ) : (
              /* Confirm Delete Dialog */
              <div className="space-y-4">
                <div className="w-14 h-14 bg-rose-50 rounded-2xl border border-rose-200 flex items-center justify-center text-rose-600">
                  <Trash2 className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-900">Confirm Variety Deletion</h3>
                  <p className="text-xs text-slate-500 mt-1 font-medium leading-relaxed">
                    Are you sure you want to delete <strong className="text-slate-900 font-bold">{cropToDelete.name}</strong> from your farm catalog? This action cannot be undone.
                  </p>
                </div>
                <div className="flex items-center justify-end space-x-2 pt-2">
                  <button
                    onClick={() => setCropToDelete(null)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleConfirmDelete}
                    className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-black shadow-xs cursor-pointer active:scale-95"
                  >
                    Delete Variety
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Crops;
