import React, { useState, useEffect } from 'react';
import { ref, onValue, set } from '../../lib/firebase';
import { db } from '../../lib/firebase';
import { 
  Sparkles, 
  Droplet, 
  Wind, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  Flame, 
  Sun,
  Sprout,
  Check
} from 'lucide-react';
import { useUserMode } from '../../context/UserModeContext';

export interface ActionItem {
  id: string;
  plotId: string;
  crop: string;
  variety: string;
  status: 'optimal' | 'warning' | 'urgent';
  title: string;
  description: string;
  actionLabel?: string;
  deviceType?: 'irrigation' | 'hvac';
  durationMins?: number;
}

export const DailyActionBanner: React.FC = () => {
  const { isFarmer } = useUserMode();
  const [deviceStates, setDeviceStates] = useState<Record<string, any>>({});
  const [activeTimers, setActiveTimers] = useState<Record<string, number>>({});
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // Subscribe to device states in Firebase
  useEffect(() => {
    const devicesRef = ref(db, 'devices');
    const unsub = onValue(devicesRef, (snap) => {
      if (snap.exists()) {
        setDeviceStates(snap.val());
      }
    });
    return () => unsub();
  }, []);

  // Timer countdown loop
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTimers(prev => {
        const next = { ...prev };
        let changed = false;
        Object.entries(next).forEach(([key, val]) => {
          const seconds = Number(val);
          if (seconds > 1) {
            next[key] = seconds - 1;
            changed = true;
          } else {
            delete next[key];
            changed = true;
          }
        });
        return changed ? next : prev;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleTriggerAction = async (plotId: string, deviceType: 'irrigation' | 'hvac', durationMins: number = 15) => {
    const timerKey = `${plotId}_${deviceType}`;
    // Set 15 minutes countdown (simulated as 900 seconds or active display)
    setActiveTimers(prev => ({ ...prev, [timerKey]: durationMins * 60 }));

    // Actuate in Firebase Realtime Database
    await set(ref(db, `devices/${plotId}/${deviceType}`), {
      enabled: true,
      mode: 'manual',
      autoOffAt: Date.now() + durationMins * 60 * 1000
    });

    setActionSuccess(`Action initiated for ${plotId.toUpperCase()} (${deviceType === 'irrigation' ? 'Drip Irrigation ON' : 'Shade Fans ON'})`);
    setTimeout(() => setActionSuccess(null), 4000);
  };

  const actionItems: ActionItem[] = [
    {
      id: 'act_plot_1',
      plotId: 'plot_1',
      crop: 'Tomato',
      variety: 'Sarpan STH-520',
      status: 'optimal',
      title: 'Soil Moisture Optimal',
      description: 'Root zone moisture at 48%. No watering needed today.'
    },
    {
      id: 'act_plot_2',
      plotId: 'plot_2',
      crop: 'Lettuce',
      variety: 'Butterhead Green',
      status: 'warning',
      title: 'Moisture Below Baseline (52%)',
      description: 'Lettuce leaves transpiring rapidly in morning heat.',
      actionLabel: 'Water for 15 Mins',
      deviceType: 'irrigation',
      durationMins: 15
    },
    {
      id: 'act_plot_3',
      plotId: 'plot_3',
      crop: 'Pepper',
      variety: 'Bell Pepper Red',
      status: 'urgent',
      title: 'High Thermal Heat Alert (26.1°C / 31°C Peak)',
      description: 'Canopy approaching thermal stress threshold (T_upper: 32°C).',
      actionLabel: 'Turn On Shade Fans',
      deviceType: 'hvac',
      durationMins: 30
    },
    {
      id: 'act_plot_4',
      plotId: 'plot_4',
      crop: 'Strawberry',
      variety: 'Chandler Sweet',
      status: 'optimal',
      title: 'Brix & Ripeness On Track',
      description: 'Fruit sugar accumulation at 11.2 °Bx. Harvest window in ~4 days.'
    }
  ];

  return (
    <div className="bg-white/95 backdrop-blur-md rounded-3xl p-6 border border-slate-200/90 shadow-sm space-y-4 relative overflow-hidden transition-all">
      
      {/* Ambient background decoration */}
      <div className="absolute top-0 right-0 w-80 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Top Banner Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-xl bg-amber-50 text-amber-600 border border-amber-200 shadow-2xs">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
              <span>{isFarmer ? 'What Should I Do Today?' : "Today's Agronomic Action Engine"}</span>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                AI Powered &bull; Live
              </span>
            </h3>
            <p className="text-xs text-slate-500 font-medium">
              {isFarmer 
                ? 'Instant 1-tap actions to protect crop health without analyzing raw data.' 
                : 'Biophysical rules-engine prescriptive interventions mapped to device actuators.'}
            </p>
          </div>
        </div>

        {/* Global summary badge */}
        <div className="flex items-center space-x-2 text-xs font-bold self-start sm:self-auto">
          <span className="flex items-center gap-1 text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            2 Plots Optimal
          </span>
          <span className="flex items-center gap-1 text-amber-700 bg-amber-50 px-2.5 py-1 rounded-xl border border-amber-200">
            <span className="w-2 h-2 rounded-full bg-amber-500" />
            1 Water Action
          </span>
          <span className="flex items-center gap-1 text-rose-700 bg-rose-50 px-2.5 py-1 rounded-xl border border-rose-200">
            <span className="w-2 h-2 rounded-full bg-rose-500" />
            1 Fan Action
          </span>
        </div>
      </div>

      {/* Success Notification Alert */}
      {actionSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs font-bold text-emerald-800 flex items-center space-x-2 animate-fadeIn">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* 4-Plot Action Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        {actionItems.map((item) => {
          const timerKey = item.deviceType ? `${item.plotId}_${item.deviceType}` : '';
          const activeSecs = activeTimers[timerKey] || 0;
          const isActuating = activeSecs > 0 || (item.deviceType && deviceStates[item.plotId]?.[item.deviceType]?.enabled);

          const minsLeft = Math.floor(activeSecs / 60);
          const secsLeft = activeSecs % 60;

          // Traffic light status styling
          let badgeBorder = 'border-emerald-200 bg-emerald-50 text-emerald-800';
          let statusDot = 'bg-emerald-500';
          let statusText = '🟢 Optimal';

          if (item.status === 'warning') {
            badgeBorder = 'border-amber-200 bg-amber-50 text-amber-800';
            statusDot = 'bg-amber-500';
            statusText = '🟡 Attention';
          } else if (item.status === 'urgent') {
            badgeBorder = 'border-rose-200 bg-rose-50 text-rose-800';
            statusDot = 'bg-rose-500';
            statusText = '🔴 Action Needed';
          }

          return (
            <div
              key={item.id}
              className={`p-4 rounded-2xl border transition-all flex flex-col justify-between space-y-3 ${
                isActuating 
                  ? 'bg-sky-50/80 border-sky-300 ring-2 ring-sky-400/30' 
                  : item.status === 'urgent'
                  ? 'bg-rose-50/40 border-rose-200'
                  : item.status === 'warning'
                  ? 'bg-amber-50/30 border-amber-200'
                  : 'bg-slate-50/80 border-slate-200/80'
              }`}
            >
              {/* Card Top: Crop Name & Status Pill */}
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">{item.crop}</h4>
                  <p className="text-[10px] text-slate-500 font-medium">{item.variety}</p>
                </div>
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${badgeBorder}`}>
                  {statusText}
                </span>
              </div>

              {/* Card Middle: Plain English Explanation */}
              <div className="space-y-1">
                <div className="text-xs font-black text-slate-800">{item.title}</div>
                <p className="text-[11px] text-slate-600 leading-snug font-medium">
                  {item.description}
                </p>
              </div>

              {/* Card Bottom: 1-Tap Action Button or Status Indicator */}
              <div className="pt-2 border-t border-slate-200/60">
                {item.actionLabel && item.deviceType ? (
                  isActuating ? (
                    /* Active Device Feedback with Live Countdown */
                    <div className="w-full py-2 px-3 bg-sky-600 text-white font-extrabold rounded-xl text-xs flex items-center justify-between shadow-xs animate-pulse">
                      <div className="flex items-center space-x-1.5">
                        {item.deviceType === 'irrigation' ? <Droplet className="w-3.5 h-3.5 fill-current" /> : <Wind className="w-3.5 h-3.5" />}
                        <span>Running...</span>
                      </div>
                      <div className="font-mono text-[11px] font-black">
                        {activeSecs > 0 ? `${minsLeft}m ${secsLeft}s` : 'Active'}
                      </div>
                    </div>
                  ) : (
                    /* 1-Tap Execution Button */
                    <button
                      onClick={() => handleTriggerAction(item.plotId, item.deviceType!, item.durationMins || 15)}
                      className={`w-full py-2.5 px-3 rounded-xl text-xs font-black flex items-center justify-center space-x-1.5 transition-all shadow-xs cursor-pointer active:scale-95 text-white ${
                        item.status === 'urgent'
                          ? 'bg-rose-600 hover:bg-rose-700'
                          : 'bg-sky-600 hover:bg-sky-700'
                      }`}
                    >
                      {item.deviceType === 'irrigation' ? <Droplet className="w-3.5 h-3.5" /> : <Wind className="w-3.5 h-3.5" />}
                      <span>{item.actionLabel}</span>
                    </button>
                  )
                ) : (
                  <div className="flex items-center space-x-1.5 text-[11px] font-bold text-emerald-700 py-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>No Action Required Today</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default DailyActionBanner;
